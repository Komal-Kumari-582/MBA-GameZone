import React, { useState, useEffect } from 'react';
import { Navbar } from './components/Navbar';
import { HomeView } from './components/HomeView';
import { GamesHubView } from './components/GamesHubView';
import { QuizChallenge } from './components/games/QuizChallenge';
import { BusinessStrategyGame } from './components/games/BusinessStrategyGame';
import { MarketingMaster } from './components/games/MarketingMaster';
import { FinanceChallenge } from './components/games/FinanceChallenge';
import { HRManagementGame } from './components/games/HRManagementGame';
import { EntrepreneurshipSimulator } from './components/games/EntrepreneurshipSimulator';
import { CaseStudyChallenge } from './components/games/CaseStudyChallenge';
import { LeaderboardView } from './components/LeaderboardView';
import { DailyChallengeView } from './components/DailyChallengeView';
import { MentorGuideView } from './components/MentorGuideView';
import { ProfileModal } from './components/ProfileModal';
import { getProfile, saveProfile } from './utils/storage';
import { sound } from './utils/sound';
import { UserProfile } from './types';
import { Gamepad2, GraduationCap, Heart, Sparkles, BookOpen } from 'lucide-react';

export default function App() {
  const [currentView, setCurrentView] = useState<string>('home');
  const [activeGame, setActiveGame] = useState<string | null>(null);
  const [profile, setProfile] = useState<UserProfile>(getProfile());
  const [isProfileModalOpen, setIsProfileModalOpen] = useState<boolean>(false);

  // Sync sound setting
  useEffect(() => {
    sound.setEnabled(profile.soundEnabled);
  }, [profile.soundEnabled]);

  const handleRefreshProfile = () => {
    setProfile(getProfile());
  };

  const handleNavigate = (view: string) => {
    setCurrentView(view);
    setActiveGame(null);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleSelectGame = (gameId: string) => {
    setActiveGame(gameId);
    setCurrentView('games');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleBackToGames = () => {
    setActiveGame(null);
    setCurrentView('games');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleToggleSound = () => {
    const updated = { ...profile, soundEnabled: !profile.soundEnabled };
    saveProfile(updated);
    setProfile(updated);
    sound.setEnabled(updated.soundEnabled);
  };

  return (
    <div className="min-h-screen flex flex-col bg-[#0b0f19] text-slate-100 font-sans selection:bg-indigo-500 selection:text-white">
      {/* Top Navbar */}
      <Navbar
        currentView={activeGame ? 'games' : currentView}
        onNavigate={handleNavigate}
        profile={profile}
        onOpenProfile={() => setIsProfileModalOpen(true)}
        onToggleSound={handleToggleSound}
      />

      {/* Main Content Arena */}
      <main className="flex-1">
        {/* If a game is active */}
        {activeGame ? (
          <div>
            {activeGame === 'quiz' && (
              <QuizChallenge
                onBackToGames={handleBackToGames}
                onRefreshProfile={handleRefreshProfile}
              />
            )}
            {activeGame === 'businessStrategy' && (
              <BusinessStrategyGame
                onBackToGames={handleBackToGames}
                onRefreshProfile={handleRefreshProfile}
              />
            )}
            {activeGame === 'marketingMaster' && (
              <MarketingMaster
                onBackToGames={handleBackToGames}
                onRefreshProfile={handleRefreshProfile}
              />
            )}
            {activeGame === 'financeChallenge' && (
              <FinanceChallenge
                onBackToGames={handleBackToGames}
                onRefreshProfile={handleRefreshProfile}
              />
            )}
            {activeGame === 'hrManagement' && (
              <HRManagementGame
                onBackToGames={handleBackToGames}
                onRefreshProfile={handleRefreshProfile}
              />
            )}
            {activeGame === 'entrepreneurshipSimulator' && (
              <EntrepreneurshipSimulator
                onBackToGames={handleBackToGames}
                onRefreshProfile={handleRefreshProfile}
              />
            )}
            {activeGame === 'caseStudyChallenge' && (
              <CaseStudyChallenge
                onBackToGames={handleBackToGames}
                onRefreshProfile={handleRefreshProfile}
              />
            )}
          </div>
        ) : (
          /* Normal Views */
          <div>
            {currentView === 'home' && (
              <HomeView
                onNavigate={handleNavigate}
                onSelectGame={handleSelectGame}
                profile={profile}
              />
            )}

            {currentView === 'games' && (
              <GamesHubView onSelectGame={handleSelectGame} />
            )}

            {currentView === 'quiz' && (
              <QuizChallenge
                onBackToGames={() => handleNavigate('games')}
                onRefreshProfile={handleRefreshProfile}
              />
            )}

            {currentView === 'leaderboard' && (
              <LeaderboardView
                profile={profile}
                onRefreshProfile={handleRefreshProfile}
              />
            )}

            {currentView === 'daily' && (
              <DailyChallengeView
                profile={profile}
                onRefreshProfile={handleRefreshProfile}
                onNavigateGames={() => handleNavigate('games')}
              />
            )}

            {currentView === 'guide' && <MentorGuideView />}
          </div>
        )}
      </main>

      {/* Footer */}
      <footer className="border-t border-slate-800/80 bg-slate-950/70 py-8 px-4 sm:px-6 lg:px-8 mt-12">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-slate-400">
          <div className="flex items-center gap-2">
            <div className="w-6 h-6 rounded-lg bg-gradient-to-tr from-blue-600 to-indigo-600 flex items-center justify-center text-white text-[10px] font-bold">
              <Gamepad2 className="w-3.5 h-3.5" />
            </div>
            <span className="font-bold text-white font-heading">MBA GameZone</span>
            <span>— Educational Business Gaming Platform</span>
          </div>

          <div className="flex items-center gap-4">
            <button
              onClick={() => handleNavigate('guide')}
              className="hover:text-indigo-400 transition flex items-center gap-1 cursor-pointer"
            >
              <BookOpen className="w-3.5 h-3.5" />
              <span>Beginner Dev Guide & Docs</span>
            </button>
            <span className="text-slate-600">•</span>
            <span>Built for CAT, GMAT & MBA Aspirants</span>
          </div>
        </div>
      </footer>

      {/* Profile Modal */}
      <ProfileModal
        isOpen={isProfileModalOpen}
        onClose={() => setIsProfileModalOpen(false)}
        profile={profile}
        onUpdateProfile={(updated) => setProfile(updated)}
      />
    </div>
  );
}
