import React, { useState, useEffect } from 'react';
import { 
  Calendar, 
  Flame, 
  Sparkles, 
  CheckCircle2, 
  XCircle, 
  Award, 
  Brain, 
  Lightbulb, 
  ArrowRight,
  RotateCcw
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { fetchDailyChallenge, validateQuizAnswer } from '../utils/api';
import { sound } from '../utils/sound';
import { addXpAndProgress, getProfile } from '../utils/storage';
import { UserProfile } from '../types';

interface DailyChallengeViewProps {
  profile: UserProfile;
  onRefreshProfile?: () => void;
  onNavigateGames?: () => void;
}

export const DailyChallengeView: React.FC<DailyChallengeViewProps> = ({
  profile,
  onRefreshProfile,
  onNavigateGames,
}) => {
  const [challenge, setChallenge] = useState<any>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [selectedOption, setSelectedOption] = useState<number | null>(null);
  const [validation, setValidation] = useState<any>(null);
  const [claimed, setClaimed] = useState<boolean>(false);

  useEffect(() => {
    async function load() {
      const res = await fetchDailyChallenge();
      setChallenge(res);
      setLoading(false);
    }
    load();
  }, []);

  const handleSelectOption = async (index: number) => {
    if (selectedOption !== null || validation !== null) return;
    sound.playClick();
    setSelectedOption(index);

    try {
      const res = await validateQuizAnswer(challenge.id, index);
      setValidation(res);

      if (res.isCorrect) {
        sound.playSuccess();
        confetti({
          particleCount: 90,
          spread: 60,
          origin: { y: 0.6 },
        });
        // Award daily XP bonus
        addXpAndProgress(250, 'streak_3');
        setClaimed(true);
        if (onRefreshProfile) onRefreshProfile();
      } else {
        sound.playError();
      }
    } catch (e) {
      // Fallback
      const isCorrect = index === challenge.correctIndex;
      setValidation({
        isCorrect,
        correctIndex: challenge.correctIndex,
        explanation: challenge.explanation,
        concept: challenge.concept,
        examTip: challenge.examTip,
      });
      if (isCorrect) {
        sound.playSuccess();
        addXpAndProgress(250);
        setClaimed(true);
        if (onRefreshProfile) onRefreshProfile();
      } else {
        sound.playError();
      }
    }
  };

  const todayStr = new Date().toLocaleDateString('en-US', {
    weekday: 'long',
    month: 'short',
    day: 'numeric',
    year: 'numeric',
  });

  if (loading) {
    return (
      <div className="flex items-center justify-center p-16 text-slate-400">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-indigo-500 mr-3" />
        <span>Loading Daily MBA Drill...</span>
      </div>
    );
  }

  return (
    <div className="max-w-3xl mx-auto py-8 px-4 space-y-6">
      {/* Header Banner */}
      <div className="glass-panel rounded-2xl p-6 sm:p-7 border border-slate-800 space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <div className="flex items-center gap-2">
              <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-500/10 border border-amber-500/20 text-amber-300 text-xs font-semibold">
                <Flame className="w-3.5 h-3.5 text-amber-400" />
                <span>Daily MBA Mindset</span>
              </span>
              <span className="text-xs text-slate-400">{todayStr}</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold text-white font-heading mt-1">
              Daily Challenge: <span className="gradient-text">{challenge?.category}</span>
            </h1>
            <p className="text-xs sm:text-sm text-slate-400">
              Solve today's business puzzle to keep your learning streak active and bank +250 bonus XP.
            </p>
          </div>

          <div className="flex items-center gap-3 bg-slate-900/80 px-4 py-2.5 rounded-xl border border-slate-800 self-start sm:self-auto">
            <Flame className="w-6 h-6 text-amber-400 animate-pulse" />
            <div>
              <span className="text-[10px] text-slate-400 block uppercase font-bold">Active Streak</span>
              <span className="text-lg font-extrabold text-white font-heading">{profile.streak} Days</span>
            </div>
          </div>
        </div>
      </div>

      {/* Question Card */}
      <div className="glass-panel rounded-2xl p-6 sm:p-8 border border-slate-800 space-y-6 shadow-xl">
        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold px-2.5 py-0.5 rounded bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">
              Difficulty: {challenge?.difficulty}
            </span>
            <span className="text-xs font-bold text-amber-400 flex items-center gap-1">
              <Sparkles className="w-3.5 h-3.5" /> +250 Bonus XP
            </span>
          </div>
          <h2 className="text-lg sm:text-xl font-bold text-white leading-relaxed">
            {challenge?.question}
          </h2>
        </div>

        {/* 4 Options */}
        <div className="space-y-3">
          {challenge?.options?.map((opt: string, idx: number) => {
            const isSelected = selectedOption === idx;
            let style = 'bg-slate-900/70 border-slate-800 text-slate-200 hover:border-indigo-500/50 hover:bg-slate-800/80';

            if (validation !== null) {
              if (idx === validation.correctIndex) {
                style = 'bg-emerald-950/70 border-emerald-500 text-emerald-200 font-bold';
              } else if (isSelected && !validation.isCorrect) {
                style = 'bg-rose-950/70 border-rose-500 text-rose-200 font-bold';
              } else {
                style = 'bg-slate-900/40 border-slate-800/60 text-slate-500 opacity-60';
              }
            }

            return (
              <button
                key={idx}
                disabled={validation !== null}
                onClick={() => handleSelectOption(idx)}
                className={`w-full p-4 rounded-xl border text-left text-sm transition-all flex items-start gap-3 cursor-pointer ${style}`}
              >
                <span className="w-6 h-6 rounded-lg bg-slate-800 flex items-center justify-center text-xs font-bold shrink-0 text-slate-300">
                  {String.fromCharCode(65 + idx)}
                </span>
                <span className="flex-1 leading-snug">{opt}</span>

                {validation !== null && idx === validation.correctIndex && (
                  <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0 mt-0.5" />
                )}
                {validation !== null && isSelected && !validation.isCorrect && (
                  <XCircle className="w-5 h-5 text-rose-400 shrink-0 mt-0.5" />
                )}
              </button>
            );
          })}
        </div>

        {/* Feedback & Concepts */}
        {validation !== null && (
          <div className="p-5 rounded-xl border bg-slate-900/90 border-indigo-500/30 space-y-3 animate-in fade-in">
            <div className="flex items-center gap-2">
              {validation.isCorrect ? (
                <div className="flex items-center gap-2 text-emerald-400 font-bold">
                  <CheckCircle2 className="w-5 h-5" />
                  <span>Brilliant! Streak Extended & +250 XP Awarded</span>
                </div>
              ) : (
                <div className="flex items-center gap-2 text-rose-400 font-bold">
                  <XCircle className="w-5 h-5" />
                  <span>Not quite — review the concept below to master it</span>
                </div>
              )}
            </div>

            <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
              {validation.explanation}
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2 text-xs">
              {validation.concept && (
                <div className="bg-slate-950/80 p-3 rounded-lg border border-slate-800">
                  <span className="text-indigo-400 font-bold block mb-1">MBA Core Theory:</span>
                  <span className="text-slate-300">{validation.concept}</span>
                </div>
              )}
              {validation.examTip && (
                <div className="bg-slate-950/80 p-3 rounded-lg border border-slate-800">
                  <span className="text-amber-400 font-bold block mb-1">CAT / GMAT Exam Tip:</span>
                  <span className="text-slate-300">{validation.examTip}</span>
                </div>
              )}
            </div>

            {onNavigateGames && (
              <div className="pt-2 flex justify-end">
                <button
                  onClick={onNavigateGames}
                  className="py-2.5 px-6 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs flex items-center gap-2 shadow-lg transition cursor-pointer"
                >
                  <span>Explore More Games</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};
