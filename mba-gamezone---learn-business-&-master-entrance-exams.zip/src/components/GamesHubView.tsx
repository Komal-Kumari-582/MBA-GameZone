import React, { useState } from 'react';
import { 
  Sparkles, 
  Briefcase, 
  Megaphone, 
  Landmark, 
  Users2, 
  Rocket, 
  FileText, 
  ArrowRight, 
  Clock, 
  Award,
  Filter,
  CheckCircle2
} from 'lucide-react';
import { GameMetadata } from '../types';
import { sound } from '../utils/sound';

interface GamesHubViewProps {
  onSelectGame: (gameId: string) => void;
}

export const GAMES_LIST: GameMetadata[] = [
  {
    id: 'quiz',
    title: 'MBA Quiz Challenge',
    category: 'Entrance Exams',
    tagline: 'CAT & GMAT Timed Speed Drill',
    description: 'Rapid-fire multiple choice questions covering Marketing, Finance, HR, Economics, Strategy, and Entrepreneurship with server-verified explanations.',
    icon: 'Sparkles',
    difficulty: 'Intermediate',
    duration: '5 - 10 mins',
    xpReward: 300,
    color: 'from-blue-600 to-indigo-600',
  },
  {
    id: 'businessStrategy',
    title: 'Business Strategy Game',
    category: 'Strategy',
    tagline: 'Zenith Mobile 4-Quarter Executive War',
    description: 'Lead a global smartphone manufacturer against fierce rivals. Allocate capital to AI silicon R&D, navigate supply shocks, and defend share price.',
    icon: 'Briefcase',
    difficulty: 'Advanced',
    duration: '8 - 12 mins',
    xpReward: 450,
    color: 'from-indigo-600 to-purple-600',
  },
  {
    id: 'marketingMaster',
    title: 'Marketing Master',
    category: 'Marketing',
    tagline: 'Aura Botanicals 4Ps & GTM Launch',
    description: 'Master STP, value-based pricing, and micro-influencer channel mix to achieve positive ROAS and viral coefficient for an eco-luxury skincare line.',
    icon: 'Megaphone',
    difficulty: 'Intermediate',
    duration: '6 - 8 mins',
    xpReward: 350,
    color: 'from-pink-600 to-rose-600',
  },
  {
    id: 'financeChallenge',
    title: 'Finance Challenge',
    category: 'Finance',
    tagline: 'Balance Sheet & Corporate Valuation',
    description: 'Balance double-entry financial statements, compute quick liquidity ratios, and evaluate capital budgeting projects using NPV vs IRR discount rates.',
    icon: 'Landmark',
    difficulty: 'Intermediate',
    duration: '7 - 10 mins',
    xpReward: 400,
    color: 'from-emerald-600 to-teal-600',
  },
  {
    id: 'hrManagement',
    title: 'HR Management Game',
    category: 'Human Resources',
    tagline: 'CHRO Workplace & Culture Simulator',
    description: 'Step into the shoes of a Chief Human Resources Officer. Solve toxic high-performer dilemmas, return-to-office battles, and balance team retention.',
    icon: 'Users2',
    difficulty: 'Beginner',
    duration: '5 - 7 mins',
    xpReward: 300,
    color: 'from-cyan-600 to-blue-600',
  },
  {
    id: 'entrepreneurshipSimulator',
    title: 'Entrepreneurship Simulator',
    category: 'Entrepreneurship',
    tagline: 'Seed to Series A Founder Journey',
    description: 'Found "EcoPack AI" with $150k seed funding. Structure vesting co-founder equity, run pilot customer discovery, and negotiate VC term sheets.',
    icon: 'Rocket',
    difficulty: 'Advanced',
    duration: '8 - 12 mins',
    xpReward: 500,
    color: 'from-amber-500 to-orange-600',
  },
  {
    id: 'caseStudyChallenge',
    title: 'Case Study Challenge',
    category: 'Consulting',
    tagline: 'NovaStream $1.2B Live Sports Pivot',
    description: 'Harvard & Stanford style mini case study. Analyze financial exhibits, churn economics, and construct an executive board recommendation memo.',
    icon: 'FileText',
    difficulty: 'Advanced',
    duration: '10 - 15 mins',
    xpReward: 450,
    color: 'from-violet-600 to-indigo-700',
  },
];

export const GamesHubView: React.FC<GamesHubViewProps> = ({ onSelectGame }) => {
  const [selectedCategory, setSelectedCategory] = useState<string>('All');

  const categories = ['All', 'Strategy', 'Marketing', 'Finance', 'Human Resources', 'Entrepreneurship', 'Consulting'];

  const filteredGames = selectedCategory === 'All'
    ? GAMES_LIST
    : GAMES_LIST.filter((g) => g.category.toLowerCase() === selectedCategory.toLowerCase());

  const getIcon = (iconName: string) => {
    switch (iconName) {
      case 'Sparkles': return <Sparkles className="w-6 h-6 text-white" />;
      case 'Briefcase': return <Briefcase className="w-6 h-6 text-white" />;
      case 'Megaphone': return <Megaphone className="w-6 h-6 text-white" />;
      case 'Landmark': return <Landmark className="w-6 h-6 text-white" />;
      case 'Users2': return <Users2 className="w-6 h-6 text-white" />;
      case 'Rocket': return <Rocket className="w-6 h-6 text-white" />;
      case 'FileText': return <FileText className="w-6 h-6 text-white" />;
      default: return <Sparkles className="w-6 h-6 text-white" />;
    }
  };

  return (
    <div className="max-w-7xl mx-auto py-8 px-4 sm:px-6 lg:px-8 space-y-8">
      {/* Title & Filter Header */}
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
        <div>
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-indigo-500/10 border border-indigo-500/20 text-indigo-300 text-xs font-semibold mb-2">
            <Sparkles className="w-3.5 h-3.5" />
            <span>Interactive MBA Curriculum</span>
          </div>
          <h1 className="text-3xl sm:text-4xl font-extrabold text-white font-heading">
            Educational <span className="gradient-text">Games Hub</span>
          </h1>
          <p className="text-slate-400 text-sm sm:text-base max-w-2xl mt-1">
            Choose from 7 specialized business simulations designed to reinforce fundamental concepts tested in CAT, GMAT, XAT, and B-school case competitions.
          </p>
        </div>

        {/* Category Filter Pills */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-2 md:pb-0 scrollbar-none">
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => {
                sound.playClick();
                setSelectedCategory(cat);
              }}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition shrink-0 cursor-pointer ${
                selectedCategory === cat
                  ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/30'
                  : 'bg-slate-800/80 text-slate-300 hover:bg-slate-700 hover:text-white border border-slate-700'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>
      </div>

      {/* Games Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredGames.map((game) => (
          <div
            key={game.id}
            className="glass-card rounded-2xl p-6 flex flex-col justify-between transition-all duration-300 hover:-translate-y-1.5 hover:shadow-2xl hover:shadow-indigo-500/10 group cursor-pointer"
            onClick={() => {
              sound.playClick();
              onSelectGame(game.id);
            }}
          >
            <div className="space-y-4">
              {/* Card Top: Icon & Tags */}
              <div className="flex items-start justify-between">
                <div className={`w-12 h-12 rounded-xl bg-gradient-to-tr ${game.color} flex items-center justify-center shadow-lg group-hover:scale-105 transition-transform`}>
                  {getIcon(game.icon)}
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded bg-slate-800 text-slate-300 border border-slate-700">
                    {game.category}
                  </span>
                  <span className={`text-[10px] font-bold px-2 py-0.5 rounded border ${
                    game.difficulty === 'Beginner'
                      ? 'bg-emerald-950/60 text-emerald-300 border-emerald-800/40'
                      : game.difficulty === 'Intermediate'
                      ? 'bg-blue-950/60 text-blue-300 border-blue-800/40'
                      : 'bg-purple-950/60 text-purple-300 border-purple-800/40'
                  }`}>
                    {game.difficulty}
                  </span>
                </div>
              </div>

              {/* Title & Description */}
              <div>
                <h3 className="text-xl font-bold text-white group-hover:text-indigo-300 transition-colors font-heading">
                  {game.title}
                </h3>
                <p className="text-xs font-semibold text-indigo-400 mt-0.5">{game.tagline}</p>
                <p className="text-xs text-slate-400 mt-2.5 leading-relaxed line-clamp-3">
                  {game.description}
                </p>
              </div>
            </div>

            {/* Card Footer */}
            <div className="pt-6 border-t border-slate-800/80 mt-6 flex items-center justify-between">
              <div className="flex items-center gap-3 text-xs text-slate-400">
                <span className="flex items-center gap-1">
                  <Clock className="w-3.5 h-3.5 text-slate-500" />
                  {game.duration}
                </span>
                <span className="flex items-center gap-1 font-semibold text-amber-400">
                  <Award className="w-3.5 h-3.5" />
                  +{game.xpReward} XP
                </span>
              </div>

              <button
                className="p-2 rounded-xl bg-indigo-600/20 text-indigo-400 group-hover:bg-indigo-600 group-hover:text-white transition-all shadow-sm"
              >
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
