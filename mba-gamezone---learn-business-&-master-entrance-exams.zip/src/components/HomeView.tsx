import React, { useState, useEffect } from 'react';
import { 
  Sparkles, 
  Gamepad2, 
  Trophy, 
  ArrowRight, 
  Brain, 
  Flame, 
  CheckCircle2, 
  Layers, 
  BarChart3, 
  ShieldCheck, 
  GraduationCap, 
  Rocket, 
  Users, 
  Award, 
  Compass,
  Play
} from 'lucide-react';
import { UserProfile } from '../types';
import { fetchPlatformStats } from '../utils/api';
import { sound } from '../utils/sound';
import { GAMES_LIST } from './GamesHubView';

interface HomeViewProps {
  onNavigate: (view: string) => void;
  onSelectGame: (gameId: string) => void;
  profile: UserProfile;
}

export const HomeView: React.FC<HomeViewProps> = ({
  onNavigate,
  onSelectGame,
  profile,
}) => {
  const [stats, setStats] = useState<any>({
    totalGames: 7,
    totalQuestions: 15,
    totalPlayers: 8,
    avgScore: 2370,
  });

  useEffect(() => {
    async function loadStats() {
      const data = await fetchPlatformStats();
      if (data) setStats(data);
    }
    loadStats();
  }, []);

  const featuredGames = GAMES_LIST.slice(0, 4);

  return (
    <div className="space-y-16 pb-16">
      {/* HERO SECTION */}
      <section className="relative overflow-hidden pt-8 pb-12 sm:pt-14 sm:pb-20">
        {/* Glow backdrop circles */}
        <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[550px] h-[350px] bg-indigo-600/15 rounded-full blur-[120px] pointer-events-none" />
        <div className="absolute top-1/3 left-1/4 w-[300px] h-[300px] bg-purple-600/15 rounded-full blur-[100px] pointer-events-none" />

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative text-center space-y-8">
          
          {/* Badge Tag */}
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full glass-card border border-indigo-500/30 text-indigo-300 text-xs font-semibold shadow-lg shadow-indigo-950/40 animate-in fade-in slide-in-from-bottom-2">
            <span className="flex h-2 w-2 rounded-full bg-emerald-400 animate-ping" />
            <span>Interactive Business Simulations for CAT & GMAT 2026</span>
          </div>

          {/* Main Title */}
          <div className="space-y-4 max-w-4xl mx-auto">
            <h1 className="text-4xl sm:text-6xl lg:text-7xl font-extrabold text-white tracking-tight leading-[1.1] font-heading">
              Master the MBA Curricula Through{' '}
              <span className="gradient-text">High-Stakes Games</span>
            </h1>
            <p className="text-slate-300 text-base sm:text-lg lg:text-xl max-w-2xl mx-auto font-normal leading-relaxed">
              Transform dry business textbooks into dynamic decision-making arenas. Battle rival tech firms, launch viral campaigns, calculate corporate valuations, and crack entrance quizzes.
            </p>
          </div>

          {/* Action CTAs */}
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4 pt-2">
            <button
              onClick={() => {
                sound.playClick();
                onSelectGame('quiz');
              }}
              className="w-full sm:w-auto px-8 py-4 rounded-xl bg-gradient-to-r from-blue-600 via-indigo-600 to-purple-600 hover:from-blue-500 hover:to-purple-500 text-white font-bold text-base shadow-xl shadow-indigo-600/30 transition transform hover:-translate-y-0.5 cursor-pointer flex items-center justify-center gap-2.5"
            >
              <Play className="w-5 h-5 fill-current" />
              <span>Start Playing (Quiz Arena)</span>
            </button>

            <button
              onClick={() => {
                sound.playClick();
                onNavigate('games');
              }}
              className="w-full sm:w-auto px-7 py-4 rounded-xl glass-card text-slate-200 hover:text-white hover:border-indigo-500/50 text-sm font-bold transition flex items-center justify-center gap-2"
            >
              <Gamepad2 className="w-4 h-4 text-indigo-400" />
              <span>Explore All 7 Games</span>
            </button>

            <button
              onClick={() => {
                sound.playClick();
                onNavigate('daily');
              }}
              className="w-full sm:w-auto px-6 py-4 rounded-xl bg-amber-500/10 border border-amber-500/30 hover:bg-amber-500/20 text-amber-300 text-sm font-bold transition flex items-center justify-center gap-2"
            >
              <Flame className="w-4 h-4 text-amber-400" />
              <span>Daily Challenge (+250 XP)</span>
            </button>
          </div>

          {/* Real-Time Platform Statistics Strip */}
          <div className="pt-8 max-w-4xl mx-auto">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3 sm:gap-4 glass-panel p-4 sm:p-6 rounded-2xl border border-slate-800 shadow-2xl">
              <div>
                <span className="text-[11px] sm:text-xs text-slate-400 uppercase tracking-wider font-semibold">Educational Games</span>
                <p className="text-2xl sm:text-3xl font-extrabold text-indigo-400 font-heading mt-0.5">
                  {stats.totalGames} Simulations
                </p>
              </div>

              <div>
                <span className="text-[11px] sm:text-xs text-slate-400 uppercase tracking-wider font-semibold">Verified Questions</span>
                <p className="text-2xl sm:text-3xl font-extrabold text-blue-400 font-heading mt-0.5">
                  {stats.totalQuestions}+ in Bank
                </p>
              </div>

              <div>
                <span className="text-[11px] sm:text-xs text-slate-400 uppercase tracking-wider font-semibold">Ranked Aspirants</span>
                <p className="text-2xl sm:text-3xl font-extrabold text-purple-400 font-heading mt-0.5">
                  {stats.totalPlayers} Top Scholars
                </p>
              </div>

              <div>
                <span className="text-[11px] sm:text-xs text-slate-400 uppercase tracking-wider font-semibold">Average Score</span>
                <p className="text-2xl sm:text-3xl font-extrabold text-emerald-400 font-heading mt-0.5">
                  {stats.avgScore} pts
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* FEATURED EDUCATIONAL GAMES */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-3">
          <div>
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-indigo-500/10 border border-indigo-500/20 text-indigo-400 text-xs font-semibold mb-2">
              <Sparkles className="w-3.5 h-3.5" />
              <span>Recommended Games</span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-white font-heading">
              Featured Simulations
            </h2>
            <p className="text-xs sm:text-sm text-slate-400 mt-1">
              Test your analytical acumen across strategy, valuation, marketing, and venture capital.
            </p>
          </div>

          <button
            onClick={() => onNavigate('games')}
            className="flex items-center gap-1.5 text-xs sm:text-sm font-bold text-indigo-400 hover:text-indigo-300 transition"
          >
            <span>View All 7 Games</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-5">
          {featuredGames.map((game) => (
            <div
              key={game.id}
              onClick={() => {
                sound.playClick();
                onSelectGame(game.id);
              }}
              className="glass-card rounded-2xl p-5 flex flex-col justify-between transition-all duration-300 hover:-translate-y-1.5 hover:shadow-xl cursor-pointer group"
            >
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-slate-800 text-slate-300 border border-slate-700">
                    {game.category}
                  </span>
                  <span className="text-xs font-bold text-amber-400">+{game.xpReward} XP</span>
                </div>

                <h3 className="text-base font-bold text-white group-hover:text-indigo-300 transition-colors font-heading">
                  {game.title}
                </h3>
                <p className="text-xs text-slate-400 leading-relaxed line-clamp-2">
                  {game.description}
                </p>
              </div>

              <div className="pt-4 border-t border-slate-800/80 mt-4 flex items-center justify-between text-xs text-indigo-400 font-semibold group-hover:text-white">
                <span>Play Simulation</span>
                <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* WHY MBA GAMEZONE WORKS */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="glass-panel rounded-3xl p-8 sm:p-12 border border-slate-800 relative overflow-hidden space-y-8">
          <div className="max-w-2xl space-y-3">
            <span className="text-xs font-bold uppercase tracking-wider text-indigo-400">
              The Scientific Methodology
            </span>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-white font-heading">
              Why Game-Based Learning Beats Cramming
            </h2>
            <p className="text-slate-300 text-sm leading-relaxed">
              Traditional entrance exam preparation relies heavily on static PDFs and rote formula memorization. MBA GameZone embeds concepts directly into decision loops:
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="p-5 rounded-2xl bg-slate-900/60 border border-slate-800/80 space-y-2.5">
              <div className="w-10 h-10 rounded-xl bg-blue-500/20 text-blue-400 flex items-center justify-center font-bold">
                <Brain className="w-5 h-5" />
              </div>
              <h4 className="text-base font-bold text-white font-heading">Active Recall & Instant Feedback</h4>
              <p className="text-xs text-slate-400 leading-relaxed">
                Immediately discover why an answer is right or wrong with real-time server validation, Porter's frameworks, and Kotler marketing models.
              </p>
            </div>

            <div className="p-5 rounded-2xl bg-slate-900/60 border border-slate-800/80 space-y-2.5">
              <div className="w-10 h-10 rounded-xl bg-purple-500/20 text-purple-400 flex items-center justify-center font-bold">
                <BarChart3 className="w-5 h-5" />
              </div>
              <h4 className="text-base font-bold text-white font-heading">Dynamic Financial Feedback</h4>
              <p className="text-xs text-slate-400 leading-relaxed">
                Watch quarterly stock prices, market shares, and cash reserves react dynamically as you toggle R&D budgets and price points.
              </p>
            </div>

            <div className="p-5 rounded-2xl bg-slate-900/60 border border-slate-800/80 space-y-2.5">
              <div className="w-10 h-10 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center font-bold">
                <Trophy className="w-5 h-5" />
              </div>
              <h4 className="text-base font-bold text-white font-heading">Entrance Exam & Case Readiness</h4>
              <p className="text-xs text-slate-400 leading-relaxed">
                Simulates real time pressure from CAT, GMAT, and MBA summer internship case interview rounds at McKinsey, BCG, and Bain.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* EXAM READINESS MATRIX */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-6">
        <div className="text-center space-y-2">
          <h2 className="text-2xl sm:text-3xl font-extrabold text-white font-heading">
            Mapped Directly to Top Entrance Exams
          </h2>
          <p className="text-xs sm:text-sm text-slate-400 max-w-xl mx-auto">
            Our 7 games strengthen core analytical instincts for every major management entrance exam.
          </p>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3.5">
          {[
            { exam: 'CAT', focus: 'VARC passages, DILR business graphs, and Quantitative profit math' },
            { exam: 'GMAT', focus: 'Data Insights, Multi-Source reasoning, and Critical analysis' },
            { exam: 'XAT', focus: 'Decision Making (DM) dilemmas & ethical corporate tradeoffs' },
            { exam: 'SNAP / NMAT', focus: 'Speed drills, vocabulary, and general managerial awareness' },
            { exam: 'B-School Placements', focus: 'Consulting casing, financial modeling, and marketing pitches' },
          ].map((item, idx) => (
            <div key={idx} className="p-4 rounded-xl glass-panel border border-slate-800 space-y-1.5">
              <span className="text-sm font-extrabold text-indigo-400 font-heading block">{item.exam}</span>
              <p className="text-[11px] text-slate-300 leading-snug">{item.focus}</p>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
};
