import React, { useState, useEffect } from 'react';
import { 
  Trophy, 
  Medal, 
  Search, 
  GraduationCap, 
  Flame, 
  Award, 
  ArrowUpRight, 
  Filter,
  Send,
  Check,
  RotateCcw
} from 'lucide-react';
import { LeaderboardEntry, UserProfile } from '../types';
import { fetchLeaderboard, submitScore } from '../utils/api';
import { sound } from '../utils/sound';

interface LeaderboardViewProps {
  profile: UserProfile;
  onRefreshProfile?: () => void;
}

export const LeaderboardView: React.FC<LeaderboardViewProps> = ({ profile, onRefreshProfile }) => {
  const [entries, setEntries] = useState<LeaderboardEntry[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [searchTerm, setSearchTerm] = useState<string>('');
  const [filterCollege, setFilterCollege] = useState<string>('All');
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);
  const [submittedRank, setSubmittedRank] = useState<number | null>(null);

  const loadLeaderboard = async () => {
    setLoading(true);
    const data = await fetchLeaderboard();
    setEntries(data);
    setLoading(false);
  };

  useEffect(() => {
    loadLeaderboard();
  }, []);

  const colleges = ['All', ...Array.from(new Set(entries.map((e) => e.college).filter(Boolean)))];

  const filteredEntries = entries.filter((e) => {
    const matchesSearch = 
      e.playerName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      e.college.toLowerCase().includes(searchTerm.toLowerCase()) ||
      e.specialization.toLowerCase().includes(searchTerm.toLowerCase());

    const matchesCollege = filterCollege === 'All' || e.college === filterCollege;
    return matchesSearch && matchesCollege;
  });

  const top3 = entries.slice(0, 3);

  const handleSubmitScore = async () => {
    sound.playClick();
    setIsSubmitting(true);
    const res = await submitScore({
      playerName: profile.name,
      college: profile.college,
      specialization: profile.specialization,
      score: profile.xp * 2, // normalized game score
      xp: profile.xp,
      level: profile.level,
      accuracy: 92,
      streak: profile.streak,
      badges: profile.badges,
    });

    setIsSubmitting(false);
    if (res.success) {
      sound.playSuccess();
      setSubmittedRank(res.rank || 1);
      loadLeaderboard();
      if (onRefreshProfile) onRefreshProfile();
    }
  };

  return (
    <div className="max-w-7xl mx-auto py-8 px-4 sm:px-6 lg:px-8 space-y-8">
      {/* Title & Submit Action */}
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
        <div>
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-500/10 border border-amber-500/20 text-amber-300 text-xs font-semibold mb-2">
            <Trophy className="w-3.5 h-3.5" />
            <span>Global B-School Rankings</span>
          </div>
          <h1 className="text-3xl sm:text-4xl font-extrabold text-white font-heading">
            MBA Aspirant <span className="gradient-text">Leaderboard</span>
          </h1>
          <p className="text-slate-400 text-sm sm:text-base max-w-2xl mt-1">
            Compare your scores and business case performance with candidates from top international and national business schools.
          </p>
        </div>

        <button
          onClick={handleSubmitScore}
          disabled={isSubmitting}
          className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-gradient-to-r from-amber-500 to-indigo-600 hover:from-amber-400 hover:to-indigo-500 text-white font-bold text-xs shadow-lg transition self-start md:self-auto cursor-pointer"
        >
          {submittedRank ? (
            <>
              <Check className="w-4 h-4 text-emerald-300" />
              <span>Ranked #{submittedRank}! Update</span>
            </>
          ) : isSubmitting ? (
            <span>Publishing...</span>
          ) : (
            <>
              <Send className="w-4 h-4" />
              <span>Publish My Standing</span>
            </>
          )}
        </button>
      </div>

      {/* TOP 3 PODIUM */}
      {top3.length >= 3 && !searchTerm && filterCollege === 'All' && (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-2">
          {/* Rank 2 (Silver) */}
          <div className="glass-card rounded-2xl p-6 border-slate-700/80 flex flex-col items-center text-center order-2 md:order-1 relative overflow-hidden">
            <div className="absolute top-3 right-3 text-2xl font-black text-slate-500/30">#2</div>
            <div className="w-14 h-14 rounded-full bg-slate-300/20 border-2 border-slate-300 flex items-center justify-center text-2xl mb-3 shadow-lg">
              🥈
            </div>
            <h3 className="text-lg font-bold text-white font-heading">{top3[1].playerName}</h3>
            <p className="text-xs text-indigo-300 flex items-center gap-1 mt-0.5">
              <GraduationCap className="w-3.5 h-3.5" />
              {top3[1].college}
            </p>
            <div className="mt-4 pt-4 border-t border-slate-800 w-full flex justify-around text-xs">
              <div>
                <span className="text-slate-400 block text-[10px]">Score</span>
                <span className="font-bold text-white font-heading text-sm">{top3[1].score.toLocaleString()}</span>
              </div>
              <div>
                <span className="text-slate-400 block text-[10px]">Streak</span>
                <span className="font-bold text-amber-400 font-heading text-sm">{top3[1].streak}d 🔥</span>
              </div>
            </div>
          </div>

          {/* Rank 1 (Gold) */}
          <div className="glass-card rounded-2xl p-6 border-amber-500/50 bg-gradient-to-b from-amber-950/20 to-slate-900/60 flex flex-col items-center text-center order-1 md:order-2 relative overflow-hidden transform md:-translate-y-2 shadow-2xl shadow-amber-500/10">
            <div className="absolute top-3 right-3 text-2xl font-black text-amber-500/30">#1</div>
            <div className="w-16 h-16 rounded-full bg-amber-400/20 border-2 border-amber-400 flex items-center justify-center text-3xl mb-3 shadow-xl">
              👑
            </div>
            <span className="px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 text-[10px] font-bold uppercase mb-1">
              Top Scorer
            </span>
            <h3 className="text-xl font-extrabold text-white font-heading">{top3[0].playerName}</h3>
            <p className="text-xs text-amber-300 flex items-center gap-1 mt-0.5">
              <GraduationCap className="w-3.5 h-3.5" />
              {top3[0].college}
            </p>
            <div className="mt-4 pt-4 border-t border-slate-800 w-full flex justify-around text-xs">
              <div>
                <span className="text-slate-400 block text-[10px]">Score</span>
                <span className="font-extrabold text-amber-300 font-heading text-base">{top3[0].score.toLocaleString()}</span>
              </div>
              <div>
                <span className="text-slate-400 block text-[10px]">XP</span>
                <span className="font-bold text-indigo-400 font-heading text-base">{top3[0].xp.toLocaleString()}</span>
              </div>
            </div>
          </div>

          {/* Rank 3 (Bronze) */}
          <div className="glass-card rounded-2xl p-6 border-slate-700/80 flex flex-col items-center text-center order-3 relative overflow-hidden">
            <div className="absolute top-3 right-3 text-2xl font-black text-amber-700/30">#3</div>
            <div className="w-14 h-14 rounded-full bg-amber-700/20 border-2 border-amber-700 flex items-center justify-center text-2xl mb-3 shadow-lg">
              🥉
            </div>
            <h3 className="text-lg font-bold text-white font-heading">{top3[2].playerName}</h3>
            <p className="text-xs text-indigo-300 flex items-center gap-1 mt-0.5">
              <GraduationCap className="w-3.5 h-3.5" />
              {top3[2].college}
            </p>
            <div className="mt-4 pt-4 border-t border-slate-800 w-full flex justify-around text-xs">
              <div>
                <span className="text-slate-400 block text-[10px]">Score</span>
                <span className="font-bold text-white font-heading text-sm">{top3[2].score.toLocaleString()}</span>
              </div>
              <div>
                <span className="text-slate-400 block text-[10px]">Streak</span>
                <span className="font-bold text-amber-400 font-heading text-sm">{top3[2].streak}d 🔥</span>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* SEARCH & FILTERS BAR */}
      <div className="glass-panel p-4 rounded-xl border border-slate-800 flex flex-col sm:flex-row items-center gap-3">
        <div className="relative flex-1 w-full">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
          <input
            type="text"
            placeholder="Search aspirant name, college, or MBA specialization..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full bg-slate-900 border border-slate-700 rounded-lg pl-9 pr-4 py-2 text-xs sm:text-sm text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500"
          />
        </div>

        <div className="w-full sm:w-auto flex items-center gap-2">
          <Filter className="w-4 h-4 text-slate-400 shrink-0" />
          <select
            value={filterCollege}
            onChange={(e) => setFilterCollege(e.target.value)}
            className="bg-slate-900 border border-slate-700 rounded-lg px-3 py-2 text-xs sm:text-sm text-slate-200 focus:outline-none focus:border-indigo-500 w-full sm:w-auto"
          >
            {colleges.map((c) => (
              <option key={c} value={c}>{c === 'All' ? 'All B-Schools' : c}</option>
            ))}
          </select>
        </div>
      </div>

      {/* RANKINGS TABLE */}
      <div className="glass-panel rounded-2xl border border-slate-800 overflow-hidden shadow-xl">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs sm:text-sm">
            <thead className="bg-slate-900/90 text-slate-400 text-[11px] uppercase tracking-wider border-b border-slate-800">
              <tr>
                <th className="py-3.5 px-4 font-bold">Rank</th>
                <th className="py-3.5 px-4 font-bold">Player</th>
                <th className="py-3.5 px-4 font-bold hidden md:table-cell">B-School & Track</th>
                <th className="py-3.5 px-4 font-bold">Score</th>
                <th className="py-3.5 px-4 font-bold hidden sm:table-cell">Level</th>
                <th className="py-3.5 px-4 font-bold text-right">Streak</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/80">
              {filteredEntries.map((entry, idx) => (
                <tr
                  key={entry.id}
                  className="hover:bg-slate-800/40 transition-colors"
                >
                  <td className="py-3.5 px-4 font-bold font-heading">
                    {idx === 0 ? '🥇 1' : idx === 1 ? '🥈 2' : idx === 2 ? '🥉 3' : `#${idx + 1}`}
                  </td>
                  <td className="py-3.5 px-4">
                    <div className="font-bold text-white flex items-center gap-2">
                      <span>{entry.playerName}</span>
                      {entry.badges?.length > 0 && (
                        <span className="hidden lg:inline-block text-[10px] bg-indigo-950 text-indigo-300 px-1.5 py-0.5 rounded border border-indigo-800/60">
                          {entry.badges[0]}
                        </span>
                      )}
                    </div>
                    <span className="text-[11px] text-slate-400 md:hidden block">{entry.college}</span>
                  </td>
                  <td className="py-3.5 px-4 hidden md:table-cell">
                    <span className="text-slate-200 font-medium block">{entry.college}</span>
                    <span className="text-[11px] text-indigo-400">{entry.specialization}</span>
                  </td>
                  <td className="py-3.5 px-4 font-extrabold text-indigo-400 font-heading">
                    {entry.score.toLocaleString()}
                  </td>
                  <td className="py-3.5 px-4 text-slate-300 hidden sm:table-cell">
                    <span className="text-xs bg-slate-800/80 px-2 py-0.5 rounded border border-slate-700">
                      {entry.level}
                    </span>
                  </td>
                  <td className="py-3.5 px-4 text-right font-bold text-amber-400">
                    {entry.streak}d 🔥
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
