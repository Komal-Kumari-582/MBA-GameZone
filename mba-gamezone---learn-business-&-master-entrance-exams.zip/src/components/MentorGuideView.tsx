import React, { useState } from 'react';
import { 
  Code2, 
  Terminal, 
  FolderTree, 
  Layers, 
  Play, 
  Server, 
  ShieldAlert, 
  CheckCircle2, 
  Sparkles, 
  Copy, 
  ExternalLink,
  BookOpen
} from 'lucide-react';
import { API_BASE } from '../utils/api';
import { sound } from '../utils/sound';

export const MentorGuideView: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'architecture' | 'steps' | 'api' | 'deployment'>('architecture');
  const [copiedSnippet, setCopiedSnippet] = useState<string | null>(null);
  const [apiTestResponse, setApiTestResponse] = useState<string | null>(null);
  const [isTestingApi, setIsTestingApi] = useState<boolean>(false);

  const copyToClipboard = (text: string, id: string) => {
    sound.playClick();
    navigator.clipboard.writeText(text);
    setCopiedSnippet(id);
    setTimeout(() => setCopiedSnippet(null), 2000);
  };

  const runApiTest = async (endpoint: string, method = 'GET', body?: any) => {
    sound.playClick();
    setIsTestingApi(true);
    setApiTestResponse('Querying Express backend...');
    try {
      const opts: RequestInit = { method };
      if (body) {
        opts.headers = { 'Content-Type': 'application/json' };
        opts.body = JSON.stringify(body);
      }
      const res = await fetch(`${API_BASE}${endpoint}`, opts);
      const data = await res.json();
      setApiTestResponse(JSON.stringify(data, null, 2));
      sound.playSuccess();
    } catch (err: any) {
      setApiTestResponse(`Error: ${err.message}`);
      sound.playError();
    } finally {
      setIsTestingApi(false);
    }
  };

  return (
    <div className="max-w-6xl mx-auto py-8 px-4 sm:px-6 lg:px-8 space-y-8">
      {/* Header */}
      <div className="glass-panel rounded-2xl p-6 sm:p-8 border border-slate-800 space-y-3">
        <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-blue-500/10 border border-blue-500/20 text-blue-300 text-xs font-semibold">
          <BookOpen className="w-3.5 h-3.5" />
          <span>Full-Stack Coding Mentor & Documentation</span>
        </div>
        <h1 className="text-3xl sm:text-4xl font-extrabold text-white font-heading">
          Developer Guide: <span className="gradient-text">How MBA GameZone Works</span>
        </h1>
        <p className="text-slate-400 text-sm sm:text-base max-w-3xl">
          A step-by-step educational manual for students and aspiring software engineers. Learn how the React client, Express API, JSON persistence layer, and educational game engines integrate seamlessly.
        </p>

        {/* Tab Switcher */}
        <div className="flex items-center gap-2 pt-4 border-t border-slate-800/80 overflow-x-auto scrollbar-none">
          {[
            { id: 'architecture', label: '1. Architecture & Structure', icon: FolderTree },
            { id: 'steps', label: '2. 10-Step Beginner Walkthrough', icon: Layers },
            { id: 'api', label: '3. API Endpoints & Live Tester', icon: Server },
            { id: 'deployment', label: '4. Local Setup & Cloud Deploy', icon: Terminal },
          ].map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => {
                  sound.playClick();
                  setActiveTab(tab.id as any);
                }}
                className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition whitespace-nowrap cursor-pointer ${
                  isActive
                    ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/30'
                    : 'bg-slate-900/80 text-slate-400 hover:text-white hover:bg-slate-800 border border-slate-800'
                }`}
              >
                <Icon className="w-4 h-4" />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* TAB 1: ARCHITECTURE & FOLDER TREE */}
      {activeTab === 'architecture' && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div className="glass-panel rounded-2xl p-6 border border-slate-800 space-y-4">
            <h3 className="text-lg font-bold text-white font-heading flex items-center gap-2">
              <FolderTree className="w-5 h-5 text-indigo-400" />
              Project File Structure
            </h3>
            <pre className="p-4 rounded-xl bg-slate-950 font-mono text-xs text-slate-300 border border-slate-800 overflow-x-auto leading-relaxed">
{`mba-gamezone/
├── data/
│   ├── questions.json       # MBA question bank (6 categories)
│   ├── scores.json          # Persistent global leaderboard
│   └── scenarios.json       # 6 simulation game scenario datasets
├── public/
│   └── (Static web assets & favicon)
├── src/
│   ├── components/
│   │   ├── games/
│   │   │   ├── QuizChallenge.tsx             # Game 1: MBA Quiz Arena
│   │   │   ├── BusinessStrategyGame.tsx      # Game 2: 4-Quarter Strategy
│   │   │   ├── MarketingMaster.tsx           # Game 3: 4Ps & GTM Launch
│   │   │   ├── FinanceChallenge.tsx          # Game 4: Balance Sheet & Valuation
│   │   │   ├── HRManagementGame.tsx          # Game 5: CHRO People Simulator
│   │   │   ├── EntrepreneurshipSimulator.tsx # Game 6: Seed to Series A
│   │   │   └── CaseStudyChallenge.tsx        # Game 7: Harvard/Stanford Case
│   │   ├── Navbar.tsx
│   │   ├── HomeView.tsx
│   │   ├── GamesHubView.tsx
│   │   ├── LeaderboardView.tsx
│   │   ├── DailyChallengeView.tsx
│   │   └── ProfileModal.tsx
│   ├── utils/
│   │   ├── api.ts          # Express API client fetchers
│   │   ├── sound.ts        # Web Audio synthesizer sound effects
│   │   └── storage.ts      # LocalStorage & Gamification leveling
│   ├── App.tsx             # Primary router & view controller
│   ├── main.tsx            # React 19 entry point
│   └── index.css           # Tailwind CSS & design tokens
├── server.ts               # Express.js REST API + Vite Middleware
├── package.json
└── tsconfig.json`}
            </pre>
          </div>

          <div className="space-y-6">
            <div className="glass-panel rounded-2xl p-6 border border-slate-800 space-y-3">
              <h3 className="text-base font-bold text-white flex items-center gap-2">
                <Layers className="w-5 h-5 text-blue-400" />
                Frontend / Backend Separation of Concerns
              </h3>
              <p className="text-xs text-slate-300 leading-relaxed">
                <strong>1. Client Layer:</strong> Built with modern React 19, TypeScript, and Tailwind CSS. Provides instant state updates, animated visual progress, and responsive mobile rendering.
              </p>
              <p className="text-xs text-slate-300 leading-relaxed">
                <strong>2. Backend Layer:</strong> An Express.js server in <code className="text-indigo-300">server.ts</code> handles quiz answer verification (<code className="text-indigo-300">/api/quiz/validate</code>), scores persistence, and scenario serving. In development, it mounts Vite middlewares for lightning-fast live reloading.
              </p>
              <p className="text-xs text-slate-300 leading-relaxed">
                <strong>3. Storage Layer:</strong> Simple, beginner-friendly JSON files in <code className="text-indigo-300">/data/</code> act as a flat database, while LocalStorage preserves the player's personal streak, XP, and unlocked badges locally.
              </p>
            </div>

            {/* Security Explanation Note */}
            <div className="p-4 rounded-xl bg-amber-950/30 border border-amber-500/40 text-amber-200 text-xs space-y-2">
              <div className="flex items-center gap-2 font-bold text-amber-300">
                <ShieldAlert className="w-4 h-4 shrink-0" />
                <span>Security Notice for Beginners</span>
              </div>
              <p className="leading-relaxed">
                This educational portfolio project stores data in JSON files and client-side <code className="bg-black/40 px-1 py-0.5 rounded">localStorage</code> for simplicity and zero setup overhead. In production multi-tenant apps, you should never store sensitive credentials or passwords in plain text or LocalStorage. Instead, use relational SQL (PostgreSQL), secure hashed passwords (bcrypt), and JWTs in HTTP-Only cookies.
              </p>
            </div>
          </div>
        </div>
      )}

      {/* TAB 2: 10-STEP BEGINNER WALKTHROUGH */}
      {activeTab === 'steps' && (
        <div className="space-y-4">
          {[
            {
              step: 'Step 1: Prerequisites & Installation',
              content: 'Install Node.js (version 18 or 20+). Initialize a new project using `npm init -y` and install the core dependencies: `npm install express dotenv lucide-react` and dev dependencies: `npm install -D vite @vitejs/plugin-react typescript tsx @types/express`.',
            },
            {
              step: 'Step 2: Project Folder Structure',
              content: 'Create the `/data` folder for storage files (`questions.json`, `scores.json`, `scenarios.json`), the `/public` directory for assets, and `/src` for React components.',
            },
            {
              step: 'Step 3: HTML5 Entry Point',
              content: 'Build `index.html` with responsive viewport meta tags, preconnected Google Fonts (Plus Jakarta Sans), and a root `<div id="root"></div>` mounting `/src/main.tsx`.',
            },
            {
              step: 'Step 4: Modern CSS3 & Tailwind Design',
              content: 'Import Tailwind via `@import "tailwindcss";` in `src/index.css`. Define glassmorphism utilities (`backdrop-filter: blur`), dark-slate palettes, and gradient texts.',
            },
            {
              step: 'Step 5: Interactive Game Logic',
              content: 'Implement the 7 educational game modules. Maintain state for timer countdowns, streak multipliers, quarterly simulation loops, and Web Audio synthesizers for zero-latency audio feedback.',
            },
            {
              step: 'Step 6: Node.js & Express Server Setup',
              content: 'Create `server.ts`. Configure Express with `express.json()` middleware and mount Vite in middleware mode during development so both API and UI run on port 3000.',
            },
            {
              step: 'Step 7: JSON Persistence & REST Endpoints',
              content: 'Build REST endpoints: GET `/api/questions`, POST `/api/quiz/validate` (verifies answer and returns concept tips), GET/POST `/api/leaderboard`, and GET `/api/daily-challenge`.',
            },
            {
              step: 'Step 8: Running Locally',
              content: 'In `package.json`, set `"dev": "tsx server.ts"`. Run `npm run dev` in your terminal and open `http://localhost:3000` in your web browser.',
            },
            {
              step: 'Step 9: Testing & Error Handling',
              content: 'Verify edge cases: timer expiration, missing answer IDs, malformed JSON data fallbacks, and mobile screen responsiveness.',
            },
            {
              step: 'Step 10: Online Deployment',
              content: 'Build production assets using `npm run build`. Deploy the Node.js application to Google Cloud Run, Render, or Railway with `npm start`.',
            },
          ].map((item, idx) => (
            <div key={idx} className="glass-panel p-5 rounded-xl border border-slate-800 space-y-1.5">
              <h4 className="text-sm font-bold text-indigo-400 font-heading">{item.step}</h4>
              <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">{item.content}</p>
            </div>
          ))}
        </div>
      )}

      {/* TAB 3: API ENDPOINTS & LIVE TESTER */}
      {activeTab === 'api' && (
        <div className="space-y-6">
          <div className="glass-panel rounded-2xl p-6 border border-slate-800 space-y-4">
            <h3 className="text-lg font-bold text-white font-heading flex items-center gap-2">
              <Server className="w-5 h-5 text-indigo-400" />
              Interactive Express API Live Tester
            </h3>
            <p className="text-xs text-slate-300">
              Click any of the buttons below to trigger real requests to our backend Express server and inspect the live JSON response.
            </p>

            <div className="flex flex-wrap gap-2 pt-2">
              <button
                onClick={() => runApiTest('/questions?category=Marketing&limit=2')}
                className="px-3 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-xs font-bold text-white border border-slate-700 transition flex items-center gap-1.5 cursor-pointer"
              >
                <span className="text-[10px] bg-blue-600 px-1 py-0.5 rounded">GET</span>
                <span>/api/questions (Marketing)</span>
              </button>

              <button
                onClick={() => runApiTest('/quiz/validate', 'POST', { questionId: 'q1', selectedIndex: 1 })}
                className="px-3 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-xs font-bold text-white border border-slate-700 transition flex items-center gap-1.5 cursor-pointer"
              >
                <span className="text-[10px] bg-emerald-600 px-1 py-0.5 rounded">POST</span>
                <span>/api/quiz/validate (Q1 Verify)</span>
              </button>

              <button
                onClick={() => runApiTest('/leaderboard')}
                className="px-3 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-xs font-bold text-white border border-slate-700 transition flex items-center gap-1.5 cursor-pointer"
              >
                <span className="text-[10px] bg-blue-600 px-1 py-0.5 rounded">GET</span>
                <span>/api/leaderboard</span>
              </button>

              <button
                onClick={() => runApiTest('/stats')}
                className="px-3 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-xs font-bold text-white border border-slate-700 transition flex items-center gap-1.5 cursor-pointer"
              >
                <span className="text-[10px] bg-blue-600 px-1 py-0.5 rounded">GET</span>
                <span>/api/stats</span>
              </button>

              <button
                onClick={() => runApiTest('/daily-challenge')}
                className="px-3 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-xs font-bold text-white border border-slate-700 transition flex items-center gap-1.5 cursor-pointer"
              >
                <span className="text-[10px] bg-blue-600 px-1 py-0.5 rounded">GET</span>
                <span>/api/daily-challenge</span>
              </button>
            </div>

            {/* Response Console */}
            <div className="space-y-1.5 pt-2">
              <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">
                Server Output Console:
              </span>
              <pre className="p-4 rounded-xl bg-slate-950 border border-slate-800 font-mono text-xs text-emerald-400 overflow-x-auto max-h-72 leading-relaxed">
                {apiTestResponse || '// Click a button above to test the Express API live...'}
              </pre>
            </div>
          </div>
        </div>
      )}

      {/* TAB 4: DEPLOYMENT */}
      {activeTab === 'deployment' && (
        <div className="glass-panel rounded-2xl p-6 sm:p-8 border border-slate-800 space-y-6">
          <div>
            <h3 className="text-xl font-bold text-white font-heading">
              How to Run Locally and Deploy Online
            </h3>
            <p className="text-xs sm:text-sm text-slate-400 mt-1">
              Instructions for student developers running on macOS, Linux, or Windows.
            </p>
          </div>

          <div className="space-y-4">
            <div className="space-y-2">
              <h4 className="text-sm font-bold text-indigo-300">1. Local Development</h4>
              <pre className="p-3.5 rounded-xl bg-slate-950 font-mono text-xs text-slate-200 border border-slate-800">
{`# 1. Clone the project repository
git clone https://github.com/your-username/mba-gamezone.git
cd mba-gamezone

# 2. Install all dependencies
npm install

# 3. Start development server (Express + Vite)
npm run dev

# 4. Open http://localhost:3000 in your browser!`}
              </pre>
            </div>

            <div className="space-y-2">
              <h4 className="text-sm font-bold text-indigo-300">2. Production Build & Start</h4>
              <pre className="p-3.5 rounded-xl bg-slate-950 font-mono text-xs text-slate-200 border border-slate-800">
{`# Compile frontend to /dist
npm run build

# Start production server
npm start`}
              </pre>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
