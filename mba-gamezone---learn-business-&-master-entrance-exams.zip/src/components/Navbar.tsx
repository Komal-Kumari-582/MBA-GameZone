import React, { useState } from 'react';
import { 
  Gamepad2, 
  Trophy, 
  BookOpen, 
  Calendar, 
  Code2, 
  Volume2, 
  VolumeX, 
  Sparkles, 
  User, 
  Home, 
  Flame,
  Menu,
  X
} from 'lucide-react';
import { UserProfile } from '../types';
import { calculateLevel } from '../utils/storage';
import { sound } from '../utils/sound';

interface NavbarProps {
  currentView: string;
  onNavigate: (view: string) => void;
  profile: UserProfile;
  onOpenProfile: () => void;
  onToggleSound: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentView,
  onNavigate,
  profile,
  onOpenProfile,
  onToggleSound,
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const levelInfo = calculateLevel(profile.xp);

  const navItems = [
    { id: 'home', label: 'Home', icon: Home },
    { id: 'games', label: 'Games Hub', icon: Gamepad2 },
    { id: 'quiz', label: 'MBA Quiz Arena', icon: Sparkles },
    { id: 'leaderboard', label: 'Leaderboard', icon: Trophy },
    { id: 'daily', label: 'Daily Challenge', icon: Calendar },
    { id: 'guide', label: 'Dev Guide & Docs', icon: Code2 },
  ];

  const handleNav = (id: string) => {
    sound.playClick();
    onNavigate(id);
    setMobileMenuOpen(false);
  };

  return (
    <header className="sticky top-0 z-50 w-full glass-panel border-b border-slate-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          
          {/* Brand Logo */}
          <div 
            onClick={() => handleNav('home')}
            className="flex items-center gap-3 cursor-pointer group"
          >
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-blue-600 via-indigo-600 to-purple-600 flex items-center justify-center shadow-lg shadow-indigo-500/25 group-hover:scale-105 transition-transform">
              <Gamepad2 className="w-5 h-5 text-white" />
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="text-xl font-extrabold tracking-tight text-white font-heading">
                  MBA <span className="gradient-text">GameZone</span>
                </span>
                <span className="text-[10px] uppercase font-bold tracking-wider px-1.5 py-0.5 rounded bg-indigo-900/70 text-indigo-300 border border-indigo-700/50">
                  EduPlay
                </span>
              </div>
              <p className="text-[11px] text-slate-400 hidden sm:block">Learn Business Through Simulation</p>
            </div>
          </div>

          {/* Desktop Navigation Links */}
          <nav className="hidden md:flex items-center gap-1 lg:gap-2">
            {navItems.map((item) => {
              const Icon = item.icon;
              const isActive = currentView === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => handleNav(item.id)}
                  className={`flex items-center gap-2 px-3 py-1.5 rounded-lg text-sm font-medium transition-all ${
                    isActive
                      ? 'bg-gradient-to-r from-blue-600/30 to-purple-600/30 text-white border border-indigo-500/40 shadow-sm'
                      : 'text-slate-300 hover:text-white hover:bg-slate-800/60'
                  }`}
                >
                  <Icon className={`w-4 h-4 ${isActive ? 'text-indigo-400' : 'text-slate-400'}`} />
                  <span>{item.label}</span>
                </button>
              );
            })}
          </nav>

          {/* Profile & Controls */}
          <div className="flex items-center gap-2 sm:gap-3">
            
            {/* Audio FX Toggle */}
            <button
              onClick={() => {
                sound.playClick();
                onToggleSound();
              }}
              title={profile.soundEnabled ? 'Mute Game Sounds' : 'Unmute Game Sounds'}
              className="p-2 rounded-lg bg-slate-800/80 border border-slate-700/60 text-slate-300 hover:text-white hover:bg-slate-700 transition"
            >
              {profile.soundEnabled ? (
                <Volume2 className="w-4 h-4 text-emerald-400" />
              ) : (
                <VolumeX className="w-4 h-4 text-slate-500" />
              )}
            </button>

            {/* Streak Counter */}
            <div 
              title={`${profile.streak} Day Learning Streak`}
              className="hidden sm:flex items-center gap-1 px-2.5 py-1 rounded-lg bg-amber-500/10 border border-amber-500/20 text-amber-300 text-xs font-semibold"
            >
              <Flame className="w-3.5 h-3.5 text-amber-400 animate-pulse" />
              <span>{profile.streak}d</span>
            </div>

            {/* User XP & Level Pill */}
            <button
              onClick={() => {
                sound.playClick();
                onOpenProfile();
              }}
              className="flex items-center gap-2.5 pl-2 pr-3 py-1.5 rounded-xl bg-slate-900/90 border border-slate-700/80 hover:border-indigo-500/60 transition group cursor-pointer"
            >
              <div className="w-7 h-7 rounded-lg bg-gradient-to-br from-indigo-500 to-purple-600 flex items-center justify-center text-xs font-bold text-white shadow-inner">
                {levelInfo.icon}
              </div>
              <div className="text-left hidden lg:block">
                <div className="text-xs font-semibold text-slate-200 group-hover:text-white flex items-center gap-1.5">
                  <span className="truncate max-w-[100px]">{profile.name}</span>
                  <span className="text-[10px] text-indigo-400 bg-indigo-950/60 px-1 py-0.2 rounded border border-indigo-800/50">
                    {profile.xp} XP
                  </span>
                </div>
                <div className="text-[10px] text-slate-400 truncate max-w-[110px]">
                  {levelInfo.level}
                </div>
              </div>
              <User className="w-3.5 h-3.5 text-slate-400 lg:hidden" />
            </button>

            {/* Mobile Hamburger Button */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2 rounded-lg bg-slate-800 md:hidden text-slate-300 hover:text-white"
            >
              {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </div>

        {/* Mobile Dropdown Menu */}
        {mobileMenuOpen && (
          <div className="md:hidden py-3 border-t border-slate-800 space-y-1">
            {navItems.map((item) => {
              const Icon = item.icon;
              const isActive = currentView === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => handleNav(item.id)}
                  className={`w-full flex items-center gap-3 px-3 py-2 rounded-lg text-sm font-medium ${
                    isActive
                      ? 'bg-indigo-600/30 text-indigo-300 border border-indigo-500/40'
                      : 'text-slate-300 hover:bg-slate-800'
                  }`}
                >
                  <Icon className="w-4 h-4 text-indigo-400" />
                  <span>{item.label}</span>
                </button>
              );
            })}
          </div>
        )}
      </div>
    </header>
  );
};
