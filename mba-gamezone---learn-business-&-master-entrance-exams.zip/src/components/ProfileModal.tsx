import React, { useState } from 'react';
import { 
  X, 
  User, 
  GraduationCap, 
  Briefcase, 
  Award, 
  Flame, 
  Check, 
  Sparkles,
  ShieldCheck
} from 'lucide-react';
import { UserProfile } from '../types';
import { ALL_BADGES, calculateLevel, saveProfile } from '../utils/storage';
import { sound } from '../utils/sound';

interface ProfileModalProps {
  isOpen: boolean;
  onClose: () => void;
  profile: UserProfile;
  onUpdateProfile: (updated: UserProfile) => void;
}

export const ProfileModal: React.FC<ProfileModalProps> = ({
  isOpen,
  onClose,
  profile,
  onUpdateProfile,
}) => {
  if (!isOpen) return null;

  const [name, setName] = useState(profile.name);
  const [college, setCollege] = useState(profile.college);
  const [specialization, setSpecialization] = useState(profile.specialization);
  const [isSaved, setIsSaved] = useState(false);

  const levelInfo = calculateLevel(profile.xp);

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    sound.playSuccess();
    const updated: UserProfile = {
      ...profile,
      name: name.trim() || 'MBA Aspirant',
      college: college.trim() || 'Target B-School',
      specialization: specialization.trim() || 'General Management',
    };
    saveProfile(updated);
    onUpdateProfile(updated);
    setIsSaved(true);
    setTimeout(() => {
      setIsSaved(false);
      onClose();
    }, 800);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="glass-panel w-full max-w-lg rounded-2xl border border-slate-700 shadow-2xl p-6 sm:p-7 space-y-6 max-h-[90vh] overflow-y-auto">
        {/* Modal Header */}
        <div className="flex items-center justify-between border-b border-slate-800 pb-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-indigo-600 to-purple-600 flex items-center justify-center text-white font-bold shadow-md">
              {levelInfo.icon}
            </div>
            <div>
              <h2 className="text-lg font-bold text-white font-heading">Aspirant Profile</h2>
              <p className="text-xs text-slate-400">Configure your B-School credentials & view milestones</p>
            </div>
          </div>
          <button
            onClick={() => {
              sound.playClick();
              onClose();
            }}
            className="p-2 rounded-lg bg-slate-800 text-slate-400 hover:text-white hover:bg-slate-700 transition cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Level & XP Progression */}
        <div className="bg-slate-900/80 p-4 rounded-xl border border-slate-800 space-y-2.5">
          <div className="flex items-center justify-between text-xs">
            <span className="font-bold text-white flex items-center gap-1.5">
              <span>{levelInfo.icon}</span>
              <span>{levelInfo.level}</span>
            </span>
            <span className="text-indigo-400 font-bold">{profile.xp} XP</span>
          </div>

          <div className="w-full bg-slate-800 h-2.5 rounded-full overflow-hidden border border-slate-700/60">
            <div
              className="bg-gradient-to-r from-blue-500 via-indigo-500 to-purple-500 h-full transition-all duration-500"
              style={{ width: `${levelInfo.progressPercent}%` }}
            />
          </div>

          <div className="flex justify-between text-[11px] text-slate-400">
            <span>{levelInfo.minXp} XP</span>
            <span>{levelInfo.progressPercent}% to next rank</span>
            <span>{levelInfo.maxXp} XP</span>
          </div>
        </div>

        {/* Profile Edit Form */}
        <form onSubmit={handleSave} className="space-y-4">
          <div className="space-y-1.5">
            <label className="text-xs font-bold text-slate-300 uppercase tracking-wider flex items-center gap-1.5">
              <User className="w-3.5 h-3.5 text-indigo-400" /> Player Name
            </label>
            <input
              type="text"
              required
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3.5 py-2 text-sm text-white focus:outline-none focus:border-indigo-500"
              placeholder="e.g. Alex Morgan"
            />
          </div>

          <div className="space-y-1.5">
            <label className="text-xs font-bold text-slate-300 uppercase tracking-wider flex items-center gap-1.5">
              <GraduationCap className="w-3.5 h-3.5 text-blue-400" /> Target / Current B-School
            </label>
            <input
              type="text"
              required
              value={college}
              onChange={(e) => setCollege(e.target.value)}
              className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3.5 py-2 text-sm text-white focus:outline-none focus:border-indigo-500"
              placeholder="e.g. IIM Ahmedabad / Harvard / INSEAD"
            />
          </div>

          <div className="space-y-1.5">
            <label className="text-xs font-bold text-slate-300 uppercase tracking-wider flex items-center gap-1.5">
              <Briefcase className="w-3.5 h-3.5 text-purple-400" /> Specialization / Track
            </label>
            <input
              type="text"
              required
              value={specialization}
              onChange={(e) => setSpecialization(e.target.value)}
              className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3.5 py-2 text-sm text-white focus:outline-none focus:border-indigo-500"
              placeholder="e.g. Strategy, Marketing, or Private Equity"
            />
          </div>

          <button
            type="submit"
            className="w-full py-3 rounded-xl bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white font-bold text-sm shadow-lg transition flex items-center justify-center gap-2 cursor-pointer"
          >
            {isSaved ? (
              <>
                <Check className="w-4 h-4 text-emerald-300" />
                <span>Profile Updated!</span>
              </>
            ) : (
              <span>Save Profile Changes</span>
            )}
          </button>
        </form>

        {/* Unlocked Badges Gallery */}
        <div className="space-y-3 pt-2 border-t border-slate-800">
          <h4 className="text-xs font-bold text-slate-300 uppercase tracking-wider flex items-center gap-1.5">
            <Award className="w-4 h-4 text-amber-400" />
            Milestones & Unlocked Badges ({profile.badges.length}/{ALL_BADGES.length})
          </h4>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
            {ALL_BADGES.map((badge) => {
              const isUnlocked = profile.badges.includes(badge.name);
              return (
                <div
                  key={badge.id}
                  className={`p-2.5 rounded-xl border flex items-center gap-2.5 transition ${
                    isUnlocked
                      ? 'bg-slate-900/90 border-amber-500/40 text-white'
                      : 'bg-slate-950/40 border-slate-800/60 text-slate-500 opacity-50'
                  }`}
                >
                  <span className="text-xl shrink-0">{badge.icon}</span>
                  <div>
                    <p className={`text-xs font-bold leading-none ${isUnlocked ? 'text-amber-300' : 'text-slate-400'}`}>
                      {badge.name}
                    </p>
                    <p className="text-[10px] text-slate-400 mt-1 leading-tight">{badge.description}</p>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
};
