import React, { useState, useEffect } from 'react';
import { 
  Briefcase, 
  TrendingUp, 
  DollarSign, 
  PieChart, 
  Award, 
  RotateCcw, 
  ArrowRight, 
  ShieldCheck, 
  Building2,
  ChevronRight,
  Sparkles
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { fetchScenario } from '../../utils/api';
import { sound } from '../../utils/sound';
import { addXpAndProgress } from '../../utils/storage';

interface BusinessStrategyGameProps {
  onBackToGames: () => void;
  onRefreshProfile?: () => void;
}

export const BusinessStrategyGame: React.FC<BusinessStrategyGameProps> = ({ onBackToGames, onRefreshProfile }) => {
  const [loading, setLoading] = useState<boolean>(true);
  const [data, setData] = useState<any>(null);

  // Simulation State
  const [currentQuarterIndex, setCurrentQuarterIndex] = useState<number>(0);
  const [state, setState] = useState({
    cashMillions: 120,
    marketShare: 18,
    profitMargin: 12,
    brandReputation: 72,
    sharePrice: 45,
  });
  
  const [selectedOptionId, setSelectedOptionId] = useState<string | null>(null);
  const [feedback, setFeedback] = useState<string | null>(null);
  const [isGameOver, setIsGameOver] = useState<boolean>(false);
  const [history, setHistory] = useState<any[]>([]);

  useEffect(() => {
    async function loadData() {
      const scenario = await fetchScenario('businessStrategy');
      if (scenario) {
        setData(scenario);
        setState(scenario.initialState);
      }
      setLoading(false);
    }
    loadData();
  }, []);

  const handleSelectOption = (option: any) => {
    if (selectedOptionId || isGameOver) return;
    sound.playClick();
    setSelectedOptionId(option.id);
    setFeedback(option.feedback);

    // Apply impact
    const imp = option.impact;
    const newState = {
      cashMillions: Math.max(0, state.cashMillions + (imp.cash || 0)),
      marketShare: Math.min(100, Math.max(1, state.marketShare + (imp.marketShare || 0))),
      profitMargin: Math.max(-20, state.profitMargin + (imp.profitMargin || 0)),
      brandReputation: Math.min(100, Math.max(0, state.brandReputation + (imp.brandReputation || 0))),
      sharePrice: Math.max(1, state.sharePrice + (imp.sharePrice || 0)),
    };
    setState(newState);

    if ((imp.sharePrice || 0) > 0) {
      sound.playSuccess();
    } else {
      sound.playError();
    }

    setHistory((prev) => [
      ...prev,
      {
        quarter: currentQuarterIndex + 1,
        chosenTitle: option.title,
        feedback: option.feedback,
        stateAfter: newState,
      },
    ]);
  };

  const handleNextQuarter = () => {
    sound.playClick();
    if (!data) return;

    if (currentQuarterIndex + 1 < data.quarters.length) {
      setCurrentQuarterIndex((prev) => prev + 1);
      setSelectedOptionId(null);
      setFeedback(null);
    } else {
      // Game completed
      setIsGameOver(true);
      const earnedXp = Math.round(state.sharePrice * 8 + state.marketShare * 10);
      addXpAndProgress(earnedXp, 'strategy_pro');
      if (onRefreshProfile) onRefreshProfile();

      sound.playLevelUp();
      confetti({
        particleCount: 120,
        spread: 80,
        origin: { y: 0.6 },
      });
    }
  };

  const handleRestart = () => {
    sound.playClick();
    if (data) {
      setState(data.initialState);
    }
    setCurrentQuarterIndex(0);
    setSelectedOptionId(null);
    setFeedback(null);
    setIsGameOver(false);
    setHistory([]);
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center p-16 text-slate-400">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-indigo-500 mr-3" />
        <span>Loading Strategic Simulator...</span>
      </div>
    );
  }

  const currentQuarterData = data?.quarters?.[currentQuarterIndex];

  // Grade calculation
  const getGrade = () => {
    if (state.sharePrice >= 65 && state.marketShare >= 24) return { grade: 'A+', comment: 'Wall Street Star! Outstanding strategic execution and shareholder value creation.' };
    if (state.sharePrice >= 55) return { grade: 'A', comment: 'Strong Executive Performance. Solid market share and healthy balance sheet.' };
    if (state.sharePrice >= 45) return { grade: 'B', comment: 'Satisfactory. You held the company steady through competitive volatility.' };
    return { grade: 'C', comment: 'Underperformed board expectations. Heavy margin pressure or cash drain.' };
  };

  return (
    <div className="max-w-4xl mx-auto py-6 px-4 space-y-6">
      {/* Header */}
      <div className="glass-panel rounded-2xl p-6 sm:p-7 border border-slate-800 space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-xl bg-gradient-to-tr from-blue-600 to-indigo-600 flex items-center justify-center text-white shadow-lg">
              <Briefcase className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-xl sm:text-2xl font-extrabold text-white font-heading">
                  Business Strategy Game
                </h1>
                <span className="text-[10px] uppercase font-bold px-2 py-0.5 rounded bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">
                  4 Quarters
                </span>
              </div>
              <p className="text-xs text-slate-400">Zenith Mobile Corporate Board Simulator</p>
            </div>
          </div>

          <button
            onClick={onBackToGames}
            className="self-start sm:self-auto text-xs px-3 py-1.5 rounded-lg bg-slate-800 text-slate-300 hover:text-white hover:bg-slate-700 transition"
          >
            Back to Games Hub
          </button>
        </div>

        {/* Live Executive KPI Dashboard */}
        <div className="grid grid-cols-2 sm:grid-cols-5 gap-3 pt-2">
          <div className="bg-slate-900/80 p-3 rounded-xl border border-slate-800">
            <span className="text-[11px] text-slate-400 flex items-center gap-1">
              <DollarSign className="w-3 h-3 text-emerald-400" /> Cash Reserves
            </span>
            <p className="text-base sm:text-lg font-bold text-white font-heading">${state.cashMillions}M</p>
          </div>

          <div className="bg-slate-900/80 p-3 rounded-xl border border-slate-800">
            <span className="text-[11px] text-slate-400 flex items-center gap-1">
              <PieChart className="w-3 h-3 text-blue-400" /> Market Share
            </span>
            <p className="text-base sm:text-lg font-bold text-blue-300 font-heading">{state.marketShare}%</p>
          </div>

          <div className="bg-slate-900/80 p-3 rounded-xl border border-slate-800">
            <span className="text-[11px] text-slate-400 flex items-center gap-1">
              <TrendingUp className="w-3 h-3 text-indigo-400" /> Profit Margin
            </span>
            <p className={`text-base sm:text-lg font-bold font-heading ${state.profitMargin >= 0 ? 'text-indigo-300' : 'text-rose-400'}`}>
              {state.profitMargin}%
            </p>
          </div>

          <div className="bg-slate-900/80 p-3 rounded-xl border border-slate-800">
            <span className="text-[11px] text-slate-400 flex items-center gap-1">
              <ShieldCheck className="w-3 h-3 text-amber-400" /> Brand Equity
            </span>
            <p className="text-base sm:text-lg font-bold text-amber-300 font-heading">{state.brandReputation}/100</p>
          </div>

          <div className="bg-slate-900/80 p-3 rounded-xl border border-slate-800 col-span-2 sm:col-span-1">
            <span className="text-[11px] text-slate-400 flex items-center gap-1">
              <Sparkles className="w-3 h-3 text-purple-400" /> Share Price
            </span>
            <p className="text-base sm:text-lg font-bold text-emerald-400 font-heading">${state.sharePrice}</p>
          </div>
        </div>
      </div>

      {!isGameOver ? (
        /* CURRENT QUARTER SITUATION */
        <div className="glass-panel rounded-2xl p-6 sm:p-8 border border-slate-800 space-y-6 shadow-xl">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold px-3 py-1 rounded-full bg-blue-600/20 text-blue-300 border border-blue-500/30">
              Quarter {currentQuarterData?.quarter} of {data?.quarters?.length}
            </span>
            <span className="text-xs text-slate-400">Industry Rival: NexusCorp (-15% pricing)</span>
          </div>

          <div className="space-y-2">
            <h2 className="text-lg sm:text-xl font-bold text-white leading-relaxed">
              {currentQuarterData?.situation}
            </h2>
            <p className="text-xs text-slate-400">
              Select your strategic move for this quarter. Your choice directly alters margins, brand equity, cash reserves, and stock price.
            </p>
          </div>

          {/* Options */}
          <div className="space-y-3">
            {currentQuarterData?.options?.map((opt: any) => {
              const isSelected = selectedOptionId === opt.id;
              return (
                <button
                  key={opt.id}
                  disabled={selectedOptionId !== null}
                  onClick={() => handleSelectOption(opt)}
                  className={`w-full p-4 rounded-xl border text-left transition flex items-start gap-3 cursor-pointer ${
                    isSelected
                      ? 'bg-indigo-950/60 border-indigo-400 text-white shadow-lg'
                      : selectedOptionId !== null
                      ? 'bg-slate-900/30 border-slate-800/60 text-slate-500 opacity-60'
                      : 'bg-slate-900/70 border-slate-800 text-slate-200 hover:border-indigo-500/50 hover:bg-slate-800/80'
                  }`}
                >
                  <ChevronRight className={`w-5 h-5 shrink-0 mt-0.5 ${isSelected ? 'text-indigo-400' : 'text-slate-500'}`} />
                  <span className="text-sm font-medium leading-relaxed">{opt.title}</span>
                </button>
              );
            })}
          </div>

          {/* Feedback & Proceed */}
          {feedback && (
            <div className="p-4 rounded-xl bg-indigo-950/40 border border-indigo-500/40 text-indigo-100 space-y-3 animate-in fade-in">
              <div className="flex items-start gap-2">
                <Sparkles className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                <p className="text-xs sm:text-sm">{feedback}</p>
              </div>

              <div className="flex justify-end pt-1">
                <button
                  onClick={handleNextQuarter}
                  className="py-2.5 px-6 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs flex items-center gap-2 shadow-lg transition cursor-pointer"
                >
                  <span>
                    {currentQuarterIndex + 1 === data?.quarters?.length
                      ? 'View Year-End Board Review'
                      : 'Proceed to Next Quarter'}
                  </span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          )}
        </div>
      ) : (
        /* YEAR-END BOARD OF DIRECTORS REVIEW */
        <div className="glass-panel rounded-2xl p-6 sm:p-8 border border-slate-800 space-y-6 text-center">
          <div className="w-16 h-16 rounded-2xl bg-gradient-to-tr from-indigo-600 to-purple-600 mx-auto flex items-center justify-center text-white shadow-xl shadow-indigo-500/20">
            <Award className="w-8 h-8" />
          </div>

          <div>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-white font-heading">
              Fiscal Year-End <span className="gradient-text">Board Review</span>
            </h2>
            <p className="text-slate-400 text-sm mt-1">Here is the Board's appraisal of your executive decisions.</p>
          </div>

          <div className="p-6 rounded-2xl bg-slate-900/80 border border-slate-800 max-w-md mx-auto space-y-2">
            <span className="text-xs text-slate-400 uppercase tracking-widest font-bold">Executive Rating</span>
            <div className="text-5xl font-black text-indigo-400 font-heading">{getGrade().grade}</div>
            <p className="text-xs text-slate-300 font-medium">{getGrade().comment}</p>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-left">
            <div className="bg-slate-900/60 p-3 rounded-xl border border-slate-800">
              <span className="text-xs text-slate-400">Final Share Price</span>
              <p className="text-xl font-bold text-emerald-400 font-heading">${state.sharePrice}</p>
            </div>
            <div className="bg-slate-900/60 p-3 rounded-xl border border-slate-800">
              <span className="text-xs text-slate-400">Market Share</span>
              <p className="text-xl font-bold text-blue-400 font-heading">{state.marketShare}%</p>
            </div>
            <div className="bg-slate-900/60 p-3 rounded-xl border border-slate-800">
              <span className="text-xs text-slate-400">Profit Margin</span>
              <p className="text-xl font-bold text-indigo-400 font-heading">{state.profitMargin}%</p>
            </div>
            <div className="bg-slate-900/60 p-3 rounded-xl border border-slate-800">
              <span className="text-xs text-slate-400">Cash Reserves</span>
              <p className="text-xl font-bold text-white font-heading">${state.cashMillions}M</p>
            </div>
          </div>

          <div className="flex flex-wrap items-center justify-center gap-3 pt-4">
            <button
              onClick={handleRestart}
              className="py-3 px-6 rounded-xl bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white font-bold text-sm shadow-md transition flex items-center gap-2 cursor-pointer"
            >
              <RotateCcw className="w-4 h-4" />
              <span>Replay Simulation</span>
            </button>
            <button
              onClick={onBackToGames}
              className="py-3 px-6 rounded-xl bg-slate-800 text-slate-300 hover:text-white hover:bg-slate-700 text-sm font-semibold transition"
            >
              Back to Games Hub
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
