import React, { useState, useEffect } from 'react';
import { 
  FileText, 
  Table, 
  CheckCircle2, 
  XCircle, 
  RotateCcw, 
  ArrowRight, 
  Award, 
  Sparkles,
  TrendingUp,
  Briefcase
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { fetchScenario } from '../../utils/api';
import { sound } from '../../utils/sound';
import { addXpAndProgress } from '../../utils/storage';

interface CaseStudyChallengeProps {
  onBackToGames: () => void;
  onRefreshProfile?: () => void;
}

export const CaseStudyChallenge: React.FC<CaseStudyChallengeProps> = ({ onBackToGames, onRefreshProfile }) => {
  const [data, setData] = useState<any>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [currentQIndex, setCurrentQIndex] = useState<number>(0);
  const [selectedChoiceIndex, setSelectedChoiceIndex] = useState<number | null>(null);
  const [totalPoints, setTotalPoints] = useState<number>(0);
  const [isCompleted, setIsCompleted] = useState<boolean>(false);

  useEffect(() => {
    async function load() {
      const scenario = await fetchScenario('caseStudyChallenge');
      if (scenario) {
        setData(scenario);
      }
      setLoading(false);
    }
    load();
  }, []);

  const handleSelectOption = (index: number) => {
    if (selectedChoiceIndex !== null || isCompleted) return;
    sound.playClick();
    setSelectedChoiceIndex(index);

    const question = data.questions[currentQIndex];
    const option = question.options[index];

    setTotalPoints((prev) => prev + option.points);
    if (option.points >= 20) {
      sound.playSuccess();
    } else {
      sound.playError();
    }
  };

  const handleNext = () => {
    sound.playClick();
    if (!data) return;

    if (currentQIndex + 1 < data.questions.length) {
      setCurrentQIndex((prev) => prev + 1);
      setSelectedChoiceIndex(null);
    } else {
      setIsCompleted(true);
      const earnedXp = Math.round(totalPoints * 4);
      addXpAndProgress(earnedXp, 'case_champion');
      if (onRefreshProfile) onRefreshProfile();

      sound.playLevelUp();
      confetti({
        particleCount: 110,
        spread: 80,
        origin: { y: 0.6 },
      });
    }
  };

  const handleRestart = () => {
    sound.playClick();
    setCurrentQIndex(0);
    setSelectedChoiceIndex(null);
    setTotalPoints(0);
    setIsCompleted(false);
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center p-16 text-slate-400">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-indigo-500 mr-3" />
        <span>Loading Executive Case Study...</span>
      </div>
    );
  }

  const currentQ = data?.questions?.[currentQIndex];
  const chosenOption = selectedChoiceIndex !== null ? currentQ?.options?.[selectedChoiceIndex] : null;

  return (
    <div className="max-w-4xl mx-auto py-6 px-4 space-y-6">
      {/* Header */}
      <div className="glass-panel rounded-2xl p-6 sm:p-7 border border-slate-800 space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-xl bg-gradient-to-tr from-violet-600 to-indigo-600 flex items-center justify-center text-white shadow-lg">
              <FileText className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-xl sm:text-2xl font-extrabold text-white font-heading">
                  Executive Case Study Challenge
                </h1>
                <span className="text-[10px] uppercase font-bold px-2 py-0.5 rounded bg-violet-500/20 text-violet-300 border border-violet-500/30">
                  HBS / Stanford Format
                </span>
              </div>
              <p className="text-xs text-slate-400">{data?.company}</p>
            </div>
          </div>

          <button
            onClick={onBackToGames}
            className="self-start sm:self-auto text-xs px-3 py-1.5 rounded-lg bg-slate-800 text-slate-300 hover:text-white hover:bg-slate-700 transition"
          >
            Back to Games Hub
          </button>
        </div>

        {/* Case Context & Dilemma */}
        <div className="bg-slate-900/80 p-4 rounded-xl border border-slate-800 space-y-3 text-xs sm:text-sm text-slate-300">
          <div>
            <strong className="text-white block font-semibold mb-1">Executive Summary:</strong>
            <p className="text-slate-300 leading-relaxed">{data?.context?.overview}</p>
          </div>
          <div>
            <strong className="text-amber-300 block font-semibold mb-1">The Dilemma:</strong>
            <p className="text-slate-300 leading-relaxed">{data?.context?.theDilemma}</p>
          </div>
        </div>

        {/* Exhibits Table */}
        <div className="bg-slate-900/50 p-4 rounded-xl border border-slate-800 space-y-2">
          <div className="flex items-center gap-2 text-xs font-bold text-indigo-300 uppercase tracking-wider">
            <Table className="w-4 h-4" />
            <span>Exhibit 1: Key Operating & Financial Metrics</span>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-2 pt-1">
            {data?.context?.exhibits?.map((ex: any, idx: number) => (
              <div key={idx} className="p-2.5 rounded-lg bg-slate-950/60 border border-slate-800/80">
                <span className="text-[10px] text-slate-400 block">{ex.metric}</span>
                <span className="text-xs font-bold text-white font-heading">{ex.value}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {!isCompleted ? (
        <div className="glass-panel rounded-2xl p-6 sm:p-8 border border-slate-800 space-y-6 shadow-xl">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold px-3 py-1 rounded-full bg-violet-600/20 text-violet-300 border border-violet-500/30">
              Stage {currentQIndex + 1} of {data?.questions?.length}
            </span>
            <span className="text-xs text-slate-400">Board Memo Question</span>
          </div>

          <div className="space-y-2">
            <h2 className="text-base sm:text-lg font-bold text-white leading-relaxed">
              {currentQ?.prompt}
            </h2>
          </div>

          {/* Options */}
          <div className="space-y-3">
            {currentQ?.options?.map((opt: any, idx: number) => {
              const isSelected = selectedChoiceIndex === idx;
              return (
                <button
                  key={idx}
                  disabled={selectedChoiceIndex !== null}
                  onClick={() => handleSelectOption(idx)}
                  className={`w-full p-4 rounded-xl border text-left transition flex items-start gap-3 cursor-pointer ${
                    isSelected
                      ? opt.points >= 20
                        ? 'bg-emerald-950/60 border-emerald-500 text-white'
                        : 'bg-rose-950/60 border-rose-500 text-white'
                      : selectedChoiceIndex !== null
                      ? 'bg-slate-900/30 border-slate-800/60 text-slate-500 opacity-60'
                      : 'bg-slate-900/70 border-slate-800 text-slate-200 hover:border-violet-500/50 hover:bg-slate-800/80'
                  }`}
                >
                  <span className="w-6 h-6 rounded-lg bg-slate-800 flex items-center justify-center text-xs font-bold shrink-0 text-slate-300">
                    {idx + 1}
                  </span>
                  <div className="flex-1">
                    <p className="text-sm font-medium leading-relaxed">{opt.text}</p>
                    {isSelected && (
                      <p className="text-xs text-slate-300 mt-2 p-2.5 rounded bg-black/40 border border-white/10">
                        {opt.analysis}
                      </p>
                    )}
                  </div>
                </button>
              );
            })}
          </div>

          {selectedChoiceIndex !== null && (
            <div className="flex justify-end pt-3">
              <button
                onClick={handleNext}
                className="py-2.5 px-6 rounded-lg bg-violet-600 hover:bg-violet-500 text-white font-bold text-xs flex items-center gap-2 shadow-lg transition cursor-pointer"
              >
                <span>{currentQIndex + 1 === data?.questions?.length ? 'Executive Consultation Debrief' : 'Next Stage'}</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          )}
        </div>
      ) : (
        /* FINAL CASE DEBRIEF */
        <div className="glass-panel rounded-2xl p-6 sm:p-8 border border-slate-800 space-y-6 text-center">
          <div className="w-16 h-16 rounded-2xl bg-gradient-to-tr from-violet-500 to-indigo-600 mx-auto flex items-center justify-center text-white shadow-xl shadow-violet-500/20">
            <Award className="w-8 h-8" />
          </div>

          <div>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-white font-heading">
              Case Study <span className="gradient-text">Complete!</span>
            </h2>
            <p className="text-slate-400 text-sm mt-1">Strategic consulting report submitted to the Board.</p>
          </div>

          <div className="p-6 rounded-2xl bg-slate-900/80 border border-slate-800 max-w-md mx-auto space-y-2">
            <span className="text-xs text-slate-400 uppercase tracking-widest font-bold">Consulting Rating</span>
            <div className="text-5xl font-black text-violet-400 font-heading">{totalPoints} / 60</div>
            <p className="text-xs text-slate-300 font-medium">
              {totalPoints >= 50
                ? 'Senior Partner Distinction! Flawless quantitative unit economics and strategic foresight.'
                : 'Solid effort! Re-read Exhibit 1 calculations on ARPU and annual rights coverage.'}
            </p>
          </div>

          <div className="flex flex-wrap items-center justify-center gap-3 pt-4">
            <button
              onClick={handleRestart}
              className="py-3 px-6 rounded-xl bg-gradient-to-r from-violet-600 to-indigo-600 hover:from-violet-500 hover:to-indigo-500 text-white font-bold text-sm shadow-md transition flex items-center gap-2 cursor-pointer"
            >
              <RotateCcw className="w-4 h-4" />
              <span>Analyze Again</span>
            </button>
            <button
              onClick={onBackToGames}
              className="py-3 px-6 rounded-xl bg-slate-800 text-slate-300 hover:text-white hover:bg-slate-700 text-sm font-semibold transition"
            >
              Back to Games Hub
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
