import React, { useState, useEffect } from 'react';
import { 
  Rocket, 
  DollarSign, 
  Clock, 
  PieChart, 
  Sparkles, 
  CheckCircle2, 
  RotateCcw, 
  ArrowRight, 
  Award,
  ChevronRight
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { fetchScenario } from '../../utils/api';
import { sound } from '../../utils/sound';
import { addXpAndProgress } from '../../utils/storage';

interface EntrepreneurshipSimulatorProps {
  onBackToGames: () => void;
  onRefreshProfile?: () => void;
}

export const EntrepreneurshipSimulator: React.FC<EntrepreneurshipSimulatorProps> = ({ onBackToGames, onRefreshProfile }) => {
  const [data, setData] = useState<any>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [currentStageIndex, setCurrentStageIndex] = useState<number>(0);
  const [selectedChoiceIndex, setSelectedChoiceIndex] = useState<number | null>(null);
  const [isCompleted, setIsCompleted] = useState<boolean>(false);

  // Startup Metrics
  const [metrics, setMetrics] = useState({
    cash: 150000,
    runwayMonths: 12,
    equityLeft: 100,
    validationScore: 10,
  });

  useEffect(() => {
    async function load() {
      const scenario = await fetchScenario('entrepreneurshipSimulator');
      if (scenario) {
        setData(scenario);
      }
      setLoading(false);
    }
    load();
  }, []);

  const handleSelectOption = (index: number) => {
    if (selectedChoiceIndex !== null || isCompleted) return;
    sound.playClick();
    setSelectedChoiceIndex(index);

    const stage = data.stages[currentStageIndex];
    const choice = stage.choices[index];

    setMetrics({
      cash: Math.max(0, metrics.cash + (choice.cashDelta || 0)),
      runwayMonths: Math.max(0, metrics.runwayMonths + (choice.runwayMonths || 0)),
      equityLeft: choice.equityLeft ?? metrics.equityLeft,
      validationScore: Math.min(100, Math.max(0, metrics.validationScore + (choice.validationScore || 0))),
    });

    if ((choice.validationScore || 0) > 0) {
      sound.playSuccess();
    } else {
      sound.playError();
    }
  };

  const handleNext = () => {
    sound.playClick();
    if (!data) return;

    if (currentStageIndex + 1 < data.stages.length) {
      setCurrentStageIndex((prev) => prev + 1);
      setSelectedChoiceIndex(null);
    } else {
      setIsCompleted(true);
      const earnedXp = Math.round(metrics.validationScore * 4 + metrics.equityLeft * 2);
      addXpAndProgress(earnedXp, 'unicorn_founder');
      if (onRefreshProfile) onRefreshProfile();

      sound.playLevelUp();
      confetti({
        particleCount: 130,
        spread: 90,
        origin: { y: 0.6 },
      });
    }
  };

  const handleRestart = () => {
    sound.playClick();
    setCurrentStageIndex(0);
    setSelectedChoiceIndex(null);
    setIsCompleted(false);
    setMetrics({
      cash: 150000,
      runwayMonths: 12,
      equityLeft: 100,
      validationScore: 10,
    });
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center p-16 text-slate-400">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-amber-500 mr-3" />
        <span>Loading Founder Simulator...</span>
      </div>
    );
  }

  const currentStage = data?.stages?.[currentStageIndex];
  const chosenChoice = selectedChoiceIndex !== null ? currentStage?.choices?.[selectedChoiceIndex] : null;

  return (
    <div className="max-w-4xl mx-auto py-6 px-4 space-y-6">
      {/* Header */}
      <div className="glass-panel rounded-2xl p-6 sm:p-7 border border-slate-800 space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-xl bg-gradient-to-tr from-amber-500 to-orange-600 flex items-center justify-center text-white shadow-lg">
              <Rocket className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-xl sm:text-2xl font-extrabold text-white font-heading">
                  Entrepreneurship Simulator
                </h1>
                <span className="text-[10px] uppercase font-bold px-2 py-0.5 rounded bg-amber-500/20 text-amber-300 border border-amber-500/30">
                  Seed to Series A
                </span>
              </div>
              <p className="text-xs text-slate-400">Found 'EcoPack AI' — Navigate MVP build, early traction, and VC term sheets</p>
            </div>
          </div>

          <button
            onClick={onBackToGames}
            className="self-start sm:self-auto text-xs px-3 py-1.5 rounded-lg bg-slate-800 text-slate-300 hover:text-white hover:bg-slate-700 transition"
          >
            Back to Games Hub
          </button>
        </div>

        {/* Startup Cap Table & Runway Cockpit */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-2">
          <div className="bg-slate-900/80 p-3 rounded-xl border border-slate-800">
            <span className="text-[11px] text-slate-400 flex items-center gap-1">
              <DollarSign className="w-3 h-3 text-emerald-400" /> Bank Balance
            </span>
            <p className="text-base sm:text-lg font-bold text-white font-heading">
              ${(metrics.cash / 1000).toFixed(0)}k
            </p>
          </div>

          <div className="bg-slate-900/80 p-3 rounded-xl border border-slate-800">
            <span className="text-[11px] text-slate-400 flex items-center gap-1">
              <Clock className="w-3 h-3 text-amber-400" /> Cash Runway
            </span>
            <p className="text-base sm:text-lg font-bold text-amber-300 font-heading">
              {metrics.runwayMonths} Months
            </p>
          </div>

          <div className="bg-slate-900/80 p-3 rounded-xl border border-slate-800">
            <span className="text-[11px] text-slate-400 flex items-center gap-1">
              <PieChart className="w-3 h-3 text-indigo-400" /> Founder Equity
            </span>
            <p className="text-base sm:text-lg font-bold text-indigo-300 font-heading">
              {metrics.equityLeft}%
            </p>
          </div>

          <div className="bg-slate-900/80 p-3 rounded-xl border border-slate-800">
            <span className="text-[11px] text-slate-400 flex items-center gap-1">
              <Sparkles className="w-3 h-3 text-purple-400" /> PMF / Traction
            </span>
            <p className="text-base sm:text-lg font-bold text-purple-300 font-heading">
              {metrics.validationScore}/100
            </p>
          </div>
        </div>
      </div>

      {!isCompleted ? (
        <div className="glass-panel rounded-2xl p-6 sm:p-8 border border-slate-800 space-y-6 shadow-xl">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold px-3 py-1 rounded-full bg-amber-600/20 text-amber-300 border border-amber-500/30">
              Round {currentStageIndex + 1} of {data?.stages?.length}: {currentStage?.title}
            </span>
            <span className="text-xs text-slate-400">Founder Dilemma</span>
          </div>

          <div className="space-y-2">
            <h2 className="text-base sm:text-lg font-bold text-white leading-relaxed">
              {currentStage?.prompt}
            </h2>
            <p className="text-xs text-slate-400">
              Evaluate equity dilution, founder vesting, lean customer discovery, and valuation caps.
            </p>
          </div>

          {/* Options */}
          <div className="space-y-3">
            {currentStage?.choices?.map((choice: any, idx: number) => {
              const isSelected = selectedChoiceIndex === idx;
              return (
                <button
                  key={idx}
                  disabled={selectedChoiceIndex !== null}
                  onClick={() => handleSelectOption(idx)}
                  className={`w-full p-4 rounded-xl border text-left transition flex items-start gap-3 cursor-pointer ${
                    isSelected
                      ? 'bg-amber-950/60 border-amber-400 text-white shadow-lg'
                      : selectedChoiceIndex !== null
                      ? 'bg-slate-900/30 border-slate-800/60 text-slate-500 opacity-60'
                      : 'bg-slate-900/70 border-slate-800 text-slate-200 hover:border-amber-500/50 hover:bg-slate-800/80'
                  }`}
                >
                  <ChevronRight className={`w-5 h-5 shrink-0 mt-0.5 ${isSelected ? 'text-amber-400' : 'text-slate-500'}`} />
                  <span className="text-sm font-medium leading-relaxed">{choice.text}</span>
                </button>
              );
            })}
          </div>

          {/* Result Banner */}
          {chosenChoice && (
            <div className="p-4 rounded-xl bg-slate-900/90 border border-amber-500/30 space-y-2 text-xs sm:text-sm text-slate-200 animate-in fade-in">
              <strong className="text-amber-300 block font-semibold">Traction & Dilution Impact:</strong>
              <p className="text-slate-300 leading-relaxed">{chosenChoice.result}</p>
              <div className="flex justify-end pt-2">
                <button
                  onClick={handleNext}
                  className="py-2.5 px-6 rounded-lg bg-amber-600 hover:bg-amber-500 text-white font-bold text-xs flex items-center gap-2 shadow-lg transition cursor-pointer"
                >
                  <span>{currentStageIndex + 1 === data?.stages?.length ? 'Pitch Deck & Venture Appraisal' : 'Next Founder Round'}</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          )}
        </div>
      ) : (
        /* FINAL REVIEW */
        <div className="glass-panel rounded-2xl p-6 sm:p-8 border border-slate-800 space-y-6 text-center">
          <div className="w-16 h-16 rounded-2xl bg-gradient-to-tr from-amber-500 to-orange-600 mx-auto flex items-center justify-center text-white shadow-xl shadow-amber-500/20">
            <Award className="w-8 h-8" />
          </div>

          <div>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-white font-heading">
              Series A <span className="gradient-text">Fundraising Success!</span>
            </h2>
            <p className="text-slate-400 text-sm mt-1">EcoPack AI successfully crossed the seed valley of death.</p>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-left">
            <div className="bg-slate-900/60 p-3 rounded-xl border border-slate-800">
              <span className="text-xs text-slate-400">Total Treasury</span>
              <p className="text-xl font-bold text-emerald-400 font-heading">${(metrics.cash / 1000).toFixed(0)}k</p>
            </div>
            <div className="bg-slate-900/60 p-3 rounded-xl border border-slate-800">
              <span className="text-xs text-slate-400">Runway</span>
              <p className="text-xl font-bold text-amber-400 font-heading">{metrics.runwayMonths} Mo</p>
            </div>
            <div className="bg-slate-900/60 p-3 rounded-xl border border-slate-800">
              <span className="text-xs text-slate-400">Founder Stake</span>
              <p className="text-xl font-bold text-indigo-400 font-heading">{metrics.equityLeft}%</p>
            </div>
            <div className="bg-slate-900/60 p-3 rounded-xl border border-slate-800">
              <span className="text-xs text-slate-400">PMF Score</span>
              <p className="text-xl font-bold text-purple-400 font-heading">{metrics.validationScore}/100</p>
            </div>
          </div>

          <div className="flex flex-wrap items-center justify-center gap-3 pt-4">
            <button
              onClick={handleRestart}
              className="py-3 px-6 rounded-xl bg-gradient-to-r from-amber-600 to-orange-600 hover:from-amber-500 hover:to-orange-500 text-white font-bold text-sm shadow-md transition flex items-center gap-2 cursor-pointer"
            >
              <RotateCcw className="w-4 h-4" />
              <span>Bootstrap Another Startup</span>
            </button>
            <button
              onClick={onBackToGames}
              className="py-3 px-6 rounded-xl bg-slate-800 text-slate-300 hover:text-white hover:bg-slate-700 text-sm font-semibold transition"
            >
              Back to Games Hub
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
