import React, { useState, useEffect } from 'react';
import { 
  Landmark, 
  Calculator, 
  CheckCircle2, 
  XCircle, 
  RotateCcw, 
  ArrowRight, 
  Award, 
  TrendingUp, 
  Sparkles,
  HelpCircle,
  FileSpreadsheet
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { fetchScenario } from '../../utils/api';
import { sound } from '../../utils/sound';
import { addXpAndProgress } from '../../utils/storage';

interface FinanceChallengeProps {
  onBackToGames: () => void;
  onRefreshProfile?: () => void;
}

export const FinanceChallenge: React.FC<FinanceChallengeProps> = ({ onBackToGames, onRefreshProfile }) => {
  const [data, setData] = useState<any>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [currentPuzzleIndex, setCurrentPuzzleIndex] = useState<number>(0);
  const [selectedOption, setSelectedOption] = useState<number | null>(null);
  const [score, setScore] = useState<number>(0);
  const [isCompleted, setIsCompleted] = useState<boolean>(false);

  useEffect(() => {
    async function load() {
      const scenario = await fetchScenario('financeChallenge');
      if (scenario) {
        setData(scenario);
      }
      setLoading(false);
    }
    load();
  }, []);

  const handleSelectOption = (index: number) => {
    if (selectedOption !== null || isCompleted) return;
    sound.playClick();
    setSelectedOption(index);

    const puzzle = data.puzzles[currentPuzzleIndex];
    const isCorrect = index === puzzle.correctIndex;

    if (isCorrect) {
      sound.playSuccess();
      setScore((prev) => prev + 100);
    } else {
      sound.playError();
    }
  };

  const handleNext = () => {
    sound.playClick();
    if (!data) return;

    if (currentPuzzleIndex + 1 < data.puzzles.length) {
      setCurrentPuzzleIndex((prev) => prev + 1);
      setSelectedOption(null);
    } else {
      setIsCompleted(true);
      const earnedXp = Math.round(score + 150);
      addXpAndProgress(earnedXp, 'finance_whiz');
      if (onRefreshProfile) onRefreshProfile();

      sound.playLevelUp();
      confetti({
        particleCount: 100,
        spread: 70,
        origin: { y: 0.6 },
      });
    }
  };

  const handleRestart = () => {
    sound.playClick();
    setCurrentPuzzleIndex(0);
    setSelectedOption(null);
    setScore(0);
    setIsCompleted(false);
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center p-16 text-slate-400">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-emerald-500 mr-3" />
        <span>Loading Finance & Valuation Arena...</span>
      </div>
    );
  }

  const currentPuzzle = data?.puzzles?.[currentPuzzleIndex];

  return (
    <div className="max-w-4xl mx-auto py-6 px-4 space-y-6">
      {/* Header */}
      <div className="glass-panel rounded-2xl p-6 sm:p-7 border border-slate-800 space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-xl bg-gradient-to-tr from-emerald-600 to-teal-600 flex items-center justify-center text-white shadow-lg">
              <Landmark className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-xl sm:text-2xl font-extrabold text-white font-heading">
                  Finance Challenge: Accounting & Valuation
                </h1>
                <span className="text-[10px] uppercase font-bold px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                  Wall Street Module
                </span>
              </div>
              <p className="text-xs text-slate-400">Master balance sheets, working capital, and capital budgeting (NPV & IRR)</p>
            </div>
          </div>

          <button
            onClick={onBackToGames}
            className="self-start sm:self-auto text-xs px-3 py-1.5 rounded-lg bg-slate-800 text-slate-300 hover:text-white hover:bg-slate-700 transition"
          >
            Back to Games Hub
          </button>
        </div>

        {/* Financial Tools Tip */}
        <div className="bg-slate-900/60 p-3 rounded-xl border border-slate-800 flex items-center justify-between text-xs text-slate-300">
          <span className="flex items-center gap-2">
            <Calculator className="w-4 h-4 text-emerald-400" />
            Fundamental Equation: <strong className="text-emerald-300">Assets = Liabilities + Equity</strong>
          </span>
          <span className="font-bold text-emerald-400">Score: {score} pts</span>
        </div>
      </div>

      {!isCompleted ? (
        <div className="glass-panel rounded-2xl p-6 sm:p-8 border border-slate-800 space-y-6 shadow-xl">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold px-3 py-1 rounded-full bg-emerald-600/20 text-emerald-300 border border-emerald-500/30">
              Puzzle {currentPuzzleIndex + 1} of {data?.puzzles?.length}: {currentPuzzle?.type}
            </span>
            <span className="text-xs text-slate-400">+100 Pts / correct answer</span>
          </div>

          <div className="space-y-3">
            <h2 className="text-base sm:text-lg font-bold text-white leading-relaxed">
              {currentPuzzle?.question}
            </h2>
          </div>

          {/* Options */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
            {currentPuzzle?.options?.map((opt: string, idx: number) => {
              const isSelected = selectedOption === idx;
              const isCorrect = idx === currentPuzzle.correctIndex;

              let btnStyle = 'bg-slate-900/70 border-slate-800 text-slate-200 hover:border-emerald-500/50 hover:bg-slate-800/80';
              if (selectedOption !== null) {
                if (isCorrect) {
                  btnStyle = 'bg-emerald-950/70 border-emerald-500 text-emerald-200 font-bold';
                } else if (isSelected) {
                  btnStyle = 'bg-rose-950/70 border-rose-500 text-rose-200 font-bold';
                } else {
                  btnStyle = 'bg-slate-900/40 border-slate-800/60 text-slate-500 opacity-60';
                }
              }

              return (
                <button
                  key={idx}
                  disabled={selectedOption !== null}
                  onClick={() => handleSelectOption(idx)}
                  className={`p-4 rounded-xl border text-left text-sm transition-all flex items-center justify-between gap-3 cursor-pointer ${btnStyle}`}
                >
                  <div className="flex items-center gap-3">
                    <span className="w-6 h-6 rounded-lg bg-slate-800 flex items-center justify-center text-xs font-bold shrink-0 text-slate-300">
                      {String.fromCharCode(65 + idx)}
                    </span>
                    <span>{opt}</span>
                  </div>
                  {selectedOption !== null && isCorrect && (
                    <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />
                  )}
                  {selectedOption !== null && isSelected && !isCorrect && (
                    <XCircle className="w-5 h-5 text-rose-400 shrink-0" />
                  )}
                </button>
              );
            })}
          </div>

          {/* Calculation Step-by-Step Breakdown */}
          {selectedOption !== null && (
            <div className="p-4 rounded-xl bg-slate-900/90 border border-emerald-500/30 text-xs sm:text-sm text-slate-200 space-y-2 animate-in fade-in">
              <div className="flex items-center gap-2 text-emerald-400 font-bold">
                <FileSpreadsheet className="w-4 h-4" />
                <span>Financial Analysis & Formula:</span>
              </div>
              <p className="text-slate-300 leading-relaxed font-mono bg-black/40 p-3 rounded-lg border border-slate-800">
                {currentPuzzle.calculation}
              </p>
              <div className="flex justify-end pt-2">
                <button
                  onClick={handleNext}
                  className="py-2 px-5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs flex items-center gap-2 shadow-lg transition cursor-pointer"
                >
                  <span>{currentPuzzleIndex + 1 === data?.puzzles?.length ? 'View Financial Scorecard' : 'Next Puzzle'}</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          )}
        </div>
      ) : (
        /* FINAL SCORECARD */
        <div className="glass-panel rounded-2xl p-6 sm:p-8 border border-slate-800 space-y-6 text-center">
          <div className="w-16 h-16 rounded-2xl bg-gradient-to-tr from-emerald-500 to-teal-600 mx-auto flex items-center justify-center text-white shadow-xl shadow-emerald-500/20">
            <Award className="w-8 h-8" />
          </div>

          <div>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-white font-heading">
              Finance Challenge <span className="gradient-text">Complete!</span>
            </h2>
            <p className="text-slate-400 text-sm mt-1">You earned {score} points in Corporate Treasury.</p>
          </div>

          <div className="p-6 rounded-2xl bg-slate-900/80 border border-slate-800 max-w-md mx-auto space-y-2">
            <span className="text-xs text-slate-400 uppercase tracking-widest font-bold">Treasury Rank</span>
            <div className="text-5xl font-black text-emerald-400 font-heading">{score} / 300</div>
            <p className="text-xs text-slate-300 font-medium">
              {score >= 200
                ? 'Wall Street Analyst Caliber! Solid command of balance sheet mechanics and time-value of money.'
                : 'Good practice! Review DCF formulas, working capital, and acid-test ratios to improve.'}
            </p>
          </div>

          <div className="flex flex-wrap items-center justify-center gap-3 pt-4">
            <button
              onClick={handleRestart}
              className="py-3 px-6 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-bold text-sm shadow-md transition flex items-center gap-2 cursor-pointer"
            >
              <RotateCcw className="w-4 h-4" />
              <span>Retry Challenge</span>
            </button>
            <button
              onClick={onBackToGames}
              className="py-3 px-6 rounded-xl bg-slate-800 text-slate-300 hover:text-white hover:bg-slate-700 text-sm font-semibold transition"
            >
              Back to Games Hub
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
