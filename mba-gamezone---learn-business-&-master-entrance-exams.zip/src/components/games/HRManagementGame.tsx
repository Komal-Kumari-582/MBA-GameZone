import React, { useState, useEffect } from 'react';
import { 
  Users2, 
  Smile, 
  HeartHandshake, 
  Zap, 
  ArrowRight, 
  RotateCcw, 
  Award, 
  Sparkles,
  ShieldAlert,
  ChevronRight
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { fetchScenario } from '../../utils/api';
import { sound } from '../../utils/sound';
import { addXpAndProgress } from '../../utils/storage';

interface HRManagementGameProps {
  onBackToGames: () => void;
  onRefreshProfile?: () => void;
}

export const HRManagementGame: React.FC<HRManagementGameProps> = ({ onBackToGames, onRefreshProfile }) => {
  const [data, setData] = useState<any>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [currentScenarioIndex, setCurrentScenarioIndex] = useState<number>(0);
  const [selectedChoiceIndex, setSelectedChoiceIndex] = useState<number | null>(null);
  const [isCompleted, setIsCompleted] = useState<boolean>(false);

  // Team Health Metrics
  const [metrics, setMetrics] = useState({
    morale: 65,
    retention: 78,
    productivity: 70,
  });

  useEffect(() => {
    async function load() {
      const scenario = await fetchScenario('hrManagement');
      if (scenario) {
        setData(scenario);
      }
      setLoading(false);
    }
    load();
  }, []);

  const handleSelectOption = (index: number) => {
    if (selectedChoiceIndex !== null || isCompleted) return;
    sound.playClick();
    setSelectedChoiceIndex(index);

    const scenario = data.scenarios[currentScenarioIndex];
    const opt = scenario.options[index];

    const newMorale = Math.min(100, Math.max(0, metrics.morale + (opt.impact.morale || 0)));
    const newRetention = Math.min(100, Math.max(0, metrics.retention + (opt.impact.retention || 0)));
    const newProductivity = Math.min(100, Math.max(0, metrics.productivity + (opt.impact.productivity || 0)));

    setMetrics({
      morale: newMorale,
      retention: newRetention,
      productivity: newProductivity,
    });

    if (opt.impact.morale >= 0 && opt.impact.retention >= 0) {
      sound.playSuccess();
    } else {
      sound.playError();
    }
  };

  const handleNext = () => {
    sound.playClick();
    if (!data) return;

    if (currentScenarioIndex + 1 < data.scenarios.length) {
      setCurrentScenarioIndex((prev) => prev + 1);
      setSelectedChoiceIndex(null);
    } else {
      setIsCompleted(true);
      const avgHealth = Math.round((metrics.morale + metrics.retention + metrics.productivity) / 3);
      const earnedXp = Math.round(avgHealth * 3);
      addXpAndProgress(earnedXp, 'hr_champion');
      if (onRefreshProfile) onRefreshProfile();

      sound.playLevelUp();
      confetti({
        particleCount: 100,
        spread: 70,
        origin: { y: 0.6 },
      });
    }
  };

  const handleRestart = () => {
    sound.playClick();
    setCurrentScenarioIndex(0);
    setSelectedChoiceIndex(null);
    setIsCompleted(false);
    setMetrics({ morale: 65, retention: 78, productivity: 70 });
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center p-16 text-slate-400">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-indigo-500 mr-3" />
        <span>Loading HR & Organizational Simulator...</span>
      </div>
    );
  }

  const currentScenario = data?.scenarios?.[currentScenarioIndex];
  const chosenOption = selectedChoiceIndex !== null ? currentScenario?.options?.[selectedChoiceIndex] : null;

  return (
    <div className="max-w-4xl mx-auto py-6 px-4 space-y-6">
      {/* Header */}
      <div className="glass-panel rounded-2xl p-6 sm:p-7 border border-slate-800 space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-xl bg-gradient-to-tr from-cyan-600 to-blue-600 flex items-center justify-center text-white shadow-lg">
              <Users2 className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-xl sm:text-2xl font-extrabold text-white font-heading">
                  HR Management Game
                </h1>
                <span className="text-[10px] uppercase font-bold px-2 py-0.5 rounded bg-cyan-500/20 text-cyan-300 border border-cyan-500/30">
                  CHRO Suite
                </span>
              </div>
              <p className="text-xs text-slate-400">Navigate people conflicts, talent retention, and organizational culture</p>
            </div>
          </div>

          <button
            onClick={onBackToGames}
            className="self-start sm:self-auto text-xs px-3 py-1.5 rounded-lg bg-slate-800 text-slate-300 hover:text-white hover:bg-slate-700 transition"
          >
            Back to Games Hub
          </button>
        </div>

        {/* Live Team Health Meters */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-2">
          <div className="bg-slate-900/80 p-3 rounded-xl border border-slate-800">
            <div className="flex items-center justify-between text-xs text-slate-300 mb-1">
              <span className="flex items-center gap-1.5">
                <Smile className="w-4 h-4 text-amber-400" /> Team Morale
              </span>
              <span className="font-bold text-amber-300">{metrics.morale}%</span>
            </div>
            <div className="w-full bg-slate-800 h-2 rounded-full overflow-hidden">
              <div className="bg-amber-400 h-full transition-all duration-500" style={{ width: `${metrics.morale}%` }} />
            </div>
          </div>

          <div className="bg-slate-900/80 p-3 rounded-xl border border-slate-800">
            <div className="flex items-center justify-between text-xs text-slate-300 mb-1">
              <span className="flex items-center gap-1.5">
                <HeartHandshake className="w-4 h-4 text-emerald-400" /> Retention Rate
              </span>
              <span className="font-bold text-emerald-300">{metrics.retention}%</span>
            </div>
            <div className="w-full bg-slate-800 h-2 rounded-full overflow-hidden">
              <div className="bg-emerald-400 h-full transition-all duration-500" style={{ width: `${metrics.retention}%` }} />
            </div>
          </div>

          <div className="bg-slate-900/80 p-3 rounded-xl border border-slate-800">
            <div className="flex items-center justify-between text-xs text-slate-300 mb-1">
              <span className="flex items-center gap-1.5">
                <Zap className="w-4 h-4 text-cyan-400" /> Team Productivity
              </span>
              <span className="font-bold text-cyan-300">{metrics.productivity}%</span>
            </div>
            <div className="w-full bg-slate-800 h-2 rounded-full overflow-hidden">
              <div className="bg-cyan-400 h-full transition-all duration-500" style={{ width: `${metrics.productivity}%` }} />
            </div>
          </div>
        </div>
      </div>

      {!isCompleted ? (
        <div className="glass-panel rounded-2xl p-6 sm:p-8 border border-slate-800 space-y-6 shadow-xl">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold px-3 py-1 rounded-full bg-cyan-600/20 text-cyan-300 border border-cyan-500/30">
              Scenario {currentScenarioIndex + 1} of {data?.scenarios?.length}: {currentScenario?.title}
            </span>
            <span className="text-xs text-slate-400">CHRO Decision Memo</span>
          </div>

          <div className="space-y-2">
            <h2 className="text-base sm:text-lg font-bold text-white leading-relaxed">
              {currentScenario?.description}
            </h2>
            <p className="text-xs text-slate-400">
              Consider psychological safety, team ripple effects, and long-term organizational health before making a policy call.
            </p>
          </div>

          {/* Options */}
          <div className="space-y-3">
            {currentScenario?.options?.map((opt: any, idx: number) => {
              const isSelected = selectedChoiceIndex === idx;
              return (
                <button
                  key={idx}
                  disabled={selectedChoiceIndex !== null}
                  onClick={() => handleSelectOption(idx)}
                  className={`w-full p-4 rounded-xl border text-left transition flex items-start gap-3 cursor-pointer ${
                    isSelected
                      ? 'bg-cyan-950/60 border-cyan-400 text-white shadow-lg'
                      : selectedChoiceIndex !== null
                      ? 'bg-slate-900/30 border-slate-800/60 text-slate-500 opacity-60'
                      : 'bg-slate-900/70 border-slate-800 text-slate-200 hover:border-cyan-500/50 hover:bg-slate-800/80'
                  }`}
                >
                  <ChevronRight className={`w-5 h-5 shrink-0 mt-0.5 ${isSelected ? 'text-cyan-400' : 'text-slate-500'}`} />
                  <span className="text-sm font-medium leading-relaxed">{opt.text}</span>
                </button>
              );
            })}
          </div>

          {/* Verdict Banner */}
          {chosenOption && (
            <div className="p-4 rounded-xl bg-slate-900/90 border border-cyan-500/30 space-y-2 text-xs sm:text-sm text-slate-200 animate-in fade-in">
              <strong className="text-cyan-300 block font-semibold">Leadership Outcome:</strong>
              <p className="text-slate-300 leading-relaxed">{chosenOption.verdict}</p>
              <div className="flex justify-end pt-2">
                <button
                  onClick={handleNext}
                  className="py-2.5 px-6 rounded-lg bg-cyan-600 hover:bg-cyan-500 text-white font-bold text-xs flex items-center gap-2 shadow-lg transition cursor-pointer"
                >
                  <span>{currentScenarioIndex + 1 === data?.scenarios?.length ? 'Executive HR Appraisal' : 'Next Workplace Dilemma'}</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          )}
        </div>
      ) : (
        /* FINAL REVIEW */
        <div className="glass-panel rounded-2xl p-6 sm:p-8 border border-slate-800 space-y-6 text-center">
          <div className="w-16 h-16 rounded-2xl bg-gradient-to-tr from-cyan-500 to-blue-600 mx-auto flex items-center justify-center text-white shadow-xl shadow-cyan-500/20">
            <Award className="w-8 h-8" />
          </div>

          <div>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-white font-heading">
              People Leadership <span className="gradient-text">Complete!</span>
            </h2>
            <p className="text-slate-400 text-sm mt-1">Here is how your company culture and productivity evolved.</p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 max-w-lg mx-auto">
            <div className="bg-slate-900/80 p-4 rounded-xl border border-slate-800">
              <span className="text-xs text-slate-400">Final Morale</span>
              <p className="text-2xl font-bold text-amber-400 font-heading">{metrics.morale}%</p>
            </div>
            <div className="bg-slate-900/80 p-4 rounded-xl border border-slate-800">
              <span className="text-xs text-slate-400">Final Retention</span>
              <p className="text-2xl font-bold text-emerald-400 font-heading">{metrics.retention}%</p>
            </div>
            <div className="bg-slate-900/80 p-4 rounded-xl border border-slate-800">
              <span className="text-xs text-slate-400">Productivity</span>
              <p className="text-2xl font-bold text-cyan-400 font-heading">{metrics.productivity}%</p>
            </div>
          </div>

          <div className="flex flex-wrap items-center justify-center gap-3 pt-4">
            <button
              onClick={handleRestart}
              className="py-3 px-6 rounded-xl bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 text-white font-bold text-sm shadow-md transition flex items-center gap-2 cursor-pointer"
            >
              <RotateCcw className="w-4 h-4" />
              <span>Restart Scenarios</span>
            </button>
            <button
              onClick={onBackToGames}
              className="py-3 px-6 rounded-xl bg-slate-800 text-slate-300 hover:text-white hover:bg-slate-700 text-sm font-semibold transition"
            >
              Back to Games Hub
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
