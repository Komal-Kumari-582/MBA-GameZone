import React, { useState, useEffect } from 'react';
import { 
  Megaphone, 
  Target, 
  DollarSign, 
  Sparkles, 
  TrendingUp, 
  Award, 
  RotateCcw, 
  ArrowRight,
  Share2,
  Users,
  CheckCircle2
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { fetchScenario } from '../../utils/api';
import { sound } from '../../utils/sound';
import { addXpAndProgress } from '../../utils/storage';

interface MarketingMasterProps {
  onBackToGames: () => void;
  onRefreshProfile?: () => void;
}

export const MarketingMaster: React.FC<MarketingMasterProps> = ({ onBackToGames, onRefreshProfile }) => {
  const [data, setData] = useState<any>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [currentStep, setCurrentStep] = useState<number>(0);
  const [selectedOption, setSelectedOption] = useState<number | null>(null);
  const [totalScore, setTotalScore] = useState<number>(0);
  const [isCompleted, setIsCompleted] = useState<boolean>(false);
  const [campaignStats, setCampaignStats] = useState<any>({
    reach: 0,
    cac: 0,
    ltv: '$0',
    roas: '0x',
    viralCoeff: 0,
  });

  useEffect(() => {
    async function load() {
      const scenario = await fetchScenario('marketingMaster');
      if (scenario) {
        setData(scenario);
      }
      setLoading(false);
    }
    load();
  }, []);

  const handleSelectOption = (index: number) => {
    if (selectedOption !== null || isCompleted) return;
    sound.playClick();
    setSelectedOption(index);

    const stepData = data.scenarios[currentStep];
    const opt = stepData.options[index];

    setTotalScore((prev) => prev + opt.score);
    if (opt.score >= 25) {
      sound.playSuccess();
    } else {
      sound.playError();
    }

    // Merge metrics
    if (opt.metrics) {
      setCampaignStats((prev: any) => ({ ...prev, ...opt.metrics }));
    }
  };

  const handleNext = () => {
    sound.playClick();
    if (!data) return;

    if (currentStep + 1 < data.scenarios.length) {
      setCurrentStep((prev) => prev + 1);
      setSelectedOption(null);
    } else {
      setIsCompleted(true);
      const earnedXp = Math.round(totalScore * 5);
      addXpAndProgress(earnedXp, 'marketing_pro');
      if (onRefreshProfile) onRefreshProfile();

      sound.playLevelUp();
      confetti({
        particleCount: 100,
        spread: 70,
        origin: { y: 0.6 },
      });
    }
  };

  const handleRestart = () => {
    sound.playClick();
    setCurrentStep(0);
    setSelectedOption(null);
    setTotalScore(0);
    setIsCompleted(false);
    setCampaignStats({
      reach: 0,
      cac: 0,
      ltv: '$0',
      roas: '0x',
      viralCoeff: 0,
    });
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center p-16 text-slate-400">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-indigo-500 mr-3" />
        <span>Loading Marketing Simulator...</span>
      </div>
    );
  }

  const currentScenario = data?.scenarios?.[currentStep];

  return (
    <div className="max-w-4xl mx-auto py-6 px-4 space-y-6">
      {/* Header */}
      <div className="glass-panel rounded-2xl p-6 sm:p-7 border border-slate-800 space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-xl bg-gradient-to-tr from-pink-600 to-purple-600 flex items-center justify-center text-white shadow-lg">
              <Megaphone className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-xl sm:text-2xl font-extrabold text-white font-heading">
                  Marketing Master: 4Ps & GTM Campaign
                </h1>
                <span className="text-[10px] uppercase font-bold px-2 py-0.5 rounded bg-pink-500/20 text-pink-300 border border-pink-500/30">
                  Aura Botanicals
                </span>
              </div>
              <p className="text-xs text-slate-400">Design an omnichannel product launch & optimize unit economics</p>
            </div>
          </div>

          <button
            onClick={onBackToGames}
            className="self-start sm:self-auto text-xs px-3 py-1.5 rounded-lg bg-slate-800 text-slate-300 hover:text-white hover:bg-slate-700 transition"
          >
            Back to Games Hub
          </button>
        </div>

        {/* Live Marketing Cockpit */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-2">
          <div className="bg-slate-900/80 p-3 rounded-xl border border-slate-800">
            <span className="text-[11px] text-slate-400 flex items-center gap-1">
              <Users className="w-3 h-3 text-pink-400" /> Targeted Reach
            </span>
            <p className="text-base sm:text-lg font-bold text-white font-heading">
              {campaignStats.reach ? campaignStats.reach.toLocaleString() : 'Pending'}
            </p>
          </div>
          <div className="bg-slate-900/80 p-3 rounded-xl border border-slate-800">
            <span className="text-[11px] text-slate-400 flex items-center gap-1">
              <DollarSign className="w-3 h-3 text-emerald-400" /> Est. CAC
            </span>
            <p className="text-base sm:text-lg font-bold text-emerald-300 font-heading">
              {campaignStats.cac ? `$${campaignStats.cac}` : 'Pending'}
            </p>
          </div>
          <div className="bg-slate-900/80 p-3 rounded-xl border border-slate-800">
            <span className="text-[11px] text-slate-400 flex items-center gap-1">
              <TrendingUp className="w-3 h-3 text-purple-400" /> Customer LTV
            </span>
            <p className="text-base sm:text-lg font-bold text-purple-300 font-heading">
              {campaignStats.ltv || 'Pending'}
            </p>
          </div>
          <div className="bg-slate-900/80 p-3 rounded-xl border border-slate-800">
            <span className="text-[11px] text-slate-400 flex items-center gap-1">
              <Sparkles className="w-3 h-3 text-amber-400" /> Est. ROAS
            </span>
            <p className="text-base sm:text-lg font-bold text-amber-300 font-heading">
              {campaignStats.roas || 'Pending'}
            </p>
          </div>
        </div>
      </div>

      {!isCompleted ? (
        /* CURRENT SCENARIO */
        <div className="glass-panel rounded-2xl p-6 sm:p-8 border border-slate-800 space-y-6 shadow-xl">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold px-3 py-1 rounded-full bg-pink-600/20 text-pink-300 border border-pink-500/30">
              Phase {currentStep + 1} of {data?.scenarios?.length}: {currentScenario?.dimension}
            </span>
            <span className="text-xs text-slate-400">Launch Budget: $50,000</span>
          </div>

          <div className="space-y-2">
            <h2 className="text-lg sm:text-xl font-bold text-white leading-relaxed">
              {currentScenario?.challenge}
            </h2>
            <p className="text-xs text-slate-400">
              Evaluate consumer psychology, willingness to pay, and marketing channels to maximize brand traction.
            </p>
          </div>

          {/* Options */}
          <div className="space-y-3">
            {currentScenario?.options?.map((opt: any, idx: number) => {
              const isSelected = selectedOption === idx;
              return (
                <button
                  key={idx}
                  disabled={selectedOption !== null}
                  onClick={() => handleSelectOption(idx)}
                  className={`w-full p-4 rounded-xl border text-left transition flex items-start gap-3 cursor-pointer ${
                    isSelected
                      ? opt.score >= 25
                        ? 'bg-emerald-950/60 border-emerald-500 text-white'
                        : 'bg-rose-950/60 border-rose-500 text-white'
                      : selectedOption !== null
                      ? 'bg-slate-900/30 border-slate-800/60 text-slate-500 opacity-60'
                      : 'bg-slate-900/70 border-slate-800 text-slate-200 hover:border-pink-500/50 hover:bg-slate-800/80'
                  }`}
                >
                  <span className="w-6 h-6 rounded-lg bg-slate-800 flex items-center justify-center text-xs font-bold shrink-0 text-slate-300">
                    {idx + 1}
                  </span>
                  <div className="flex-1">
                    <p className="text-sm font-medium leading-relaxed">{opt.text}</p>
                    {isSelected && (
                      <p className="text-xs text-slate-300 mt-2 p-2.5 rounded bg-black/40 border border-white/10">
                        {opt.feedback}
                      </p>
                    )}
                  </div>
                </button>
              );
            })}
          </div>

          {selectedOption !== null && (
            <div className="flex justify-end pt-3">
              <button
                onClick={handleNext}
                className="py-2.5 px-6 rounded-lg bg-pink-600 hover:bg-pink-500 text-white font-bold text-xs flex items-center gap-2 shadow-lg transition cursor-pointer"
              >
                <span>{currentStep + 1 === data?.scenarios?.length ? 'Final Campaign Scorecard' : 'Next GTM Phase'}</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          )}
        </div>
      ) : (
        /* FINAL CAMPAIGN SCORECARD */
        <div className="glass-panel rounded-2xl p-6 sm:p-8 border border-slate-800 space-y-6 text-center">
          <div className="w-16 h-16 rounded-2xl bg-gradient-to-tr from-pink-500 to-purple-600 mx-auto flex items-center justify-center text-white shadow-xl shadow-pink-500/20">
            <Award className="w-8 h-8" />
          </div>

          <div>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-white font-heading">
              GTM Campaign <span className="gradient-text">Complete!</span>
            </h2>
            <p className="text-slate-400 text-sm mt-1">Here is how Aura Botanicals performed in the market.</p>
          </div>

          <div className="p-6 rounded-2xl bg-slate-900/80 border border-slate-800 max-w-md mx-auto space-y-2">
            <span className="text-xs text-slate-400 uppercase tracking-widest font-bold">Campaign Score</span>
            <div className="text-5xl font-black text-pink-400 font-heading">{totalScore} / 95</div>
            <p className="text-xs text-slate-300 font-medium">
              {totalScore >= 75
                ? 'Chief Marketing Officer (CMO) Caliber! Superb alignment of 4Ps, low CAC, and viral brand coefficient.'
                : 'Decent launch, but high acquisition costs or poor channel-target fit left margin on the table.'}
            </p>
          </div>

          <div className="flex flex-wrap items-center justify-center gap-3 pt-4">
            <button
              onClick={handleRestart}
              className="py-3 px-6 rounded-xl bg-gradient-to-r from-pink-600 to-purple-600 hover:from-pink-500 hover:to-purple-500 text-white font-bold text-sm shadow-md transition flex items-center gap-2 cursor-pointer"
            >
              <RotateCcw className="w-4 h-4" />
              <span>Relaunch Campaign</span>
            </button>
            <button
              onClick={onBackToGames}
              className="py-3 px-6 rounded-xl bg-slate-800 text-slate-300 hover:text-white hover:bg-slate-700 text-sm font-semibold transition"
            >
              Back to Games Hub
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
