import React, { useState, useEffect } from 'react';
import { 
  Timer, 
  Sparkles, 
  Award, 
  RotateCcw, 
  CheckCircle2, 
  XCircle, 
  ArrowRight, 
  Flame, 
  Brain, 
  HelpCircle,
  Lightbulb,
  Check,
  Share2,
  Send
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { Question, ValidationResponse } from '../../types';
import { fetchQuestions, validateQuizAnswer, submitScore } from '../../utils/api';
import { sound } from '../../utils/sound';
import { addXpAndProgress, getProfile } from '../../utils/storage';

interface QuizChallengeProps {
  onBackToGames?: () => void;
  onRefreshProfile?: () => void;
}

export const QuizChallenge: React.FC<QuizChallengeProps> = ({ onBackToGames, onRefreshProfile }) => {
  // Settings & state
  const [category, setCategory] = useState<string>('All');
  const [difficulty, setDifficulty] = useState<string>('All');
  const [questionCount, setQuestionCount] = useState<number>(5);
  const [gameState, setGameState] = useState<'lobby' | 'playing' | 'review'>('lobby');
  
  // Game session
  const [questions, setQuestions] = useState<Question[]>([]);
  const [currentIndex, setCurrentIndex] = useState<number>(0);
  const [selectedOption, setSelectedOption] = useState<number | null>(null);
  const [validationResult, setValidationResult] = useState<ValidationResponse | null>(null);
  const [isValidating, setIsValidating] = useState<boolean>(false);
  const [timeLeft, setTimeLeft] = useState<number>(30);
  
  // Score & stats
  const [score, setScore] = useState<number>(0);
  const [correctAnswersCount, setCorrectAnswersCount] = useState<number>(0);
  const [streak, setStreak] = useState<number>(0);
  const [bestStreak, setBestStreak] = useState<number>(0);
  const [history, setHistory] = useState<{ question: Question; selected: number; result: ValidationResponse }[]>([]);
  
  // Submission
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);
  const [submissionSuccess, setSubmissionSuccess] = useState<string | null>(null);

  const categories = ['All', 'Marketing', 'Finance', 'HR', 'Economics', 'Business Strategy', 'Entrepreneurship'];
  const difficulties = ['All', 'Beginner', 'Intermediate', 'Advanced'];

  // Start the quiz
  const handleStartQuiz = async () => {
    sound.playClick();
    const fetched = await fetchQuestions(category, difficulty, questionCount);
    if (!fetched || fetched.length === 0) {
      alert('No questions found for the selected criteria. Try selecting "All".');
      return;
    }
    
    // Shuffle questions
    const shuffled = [...fetched].sort(() => Math.random() - 0.5);
    setQuestions(shuffled);
    setCurrentIndex(0);
    setScore(0);
    setCorrectAnswersCount(0);
    setStreak(0);
    setBestStreak(0);
    setHistory([]);
    setSelectedOption(null);
    setValidationResult(null);
    setTimeLeft(30);
    setGameState('playing');
    setSubmissionSuccess(null);
  };

  // Timer countdown
  useEffect(() => {
    if (gameState !== 'playing' || validationResult !== null) return;

    if (timeLeft <= 0) {
      handleTimeExpired();
      return;
    }

    const timer = setInterval(() => {
      setTimeLeft((prev) => prev - 1);
    }, 1000);

    return () => clearInterval(timer);
  }, [gameState, timeLeft, validationResult]);

  // When time runs out
  const handleTimeExpired = async () => {
    if (selectedOption !== null || validationResult !== null) return;
    sound.playError();
    // Validate with wrong selection (-1)
    const currentQ = questions[currentIndex];
    setIsValidating(true);
    try {
      const res = await validateQuizAnswer(currentQ.id, -1);
      setValidationResult(res);
      setStreak(0);
      setHistory((prev) => [...prev, { question: currentQ, selected: -1, result: res }]);
    } catch (e) {
      // Fallback
      setValidationResult({
        success: true,
        questionId: currentQ.id,
        isCorrect: false,
        correctIndex: currentQ.correctIndex ?? 0,
        explanation: currentQ.explanation || 'Time ran out before an answer was chosen.',
        concept: currentQ.concept || 'Business Fundamentals',
        examTip: currentQ.examTip || 'Time management is essential in CAT and GMAT exams.',
        points: 0,
      });
    } finally {
      setIsValidating(false);
    }
  };

  // Option Click & Server Validation
  const handleSelectOption = async (index: number) => {
    if (selectedOption !== null || validationResult !== null || isValidating) return;
    
    sound.playClick();
    setSelectedOption(index);
    setIsValidating(true);

    const currentQ = questions[currentIndex];
    try {
      const res = await validateQuizAnswer(currentQ.id, index);
      setValidationResult(res);

      if (res.isCorrect) {
        sound.playSuccess();
        const streakMultiplier = streak >= 2 ? 1.5 : 1.0;
        const earned = Math.round(res.points * streakMultiplier);
        setScore((prev) => prev + earned);
        setCorrectAnswersCount((prev) => prev + 1);
        const newStreak = streak + 1;
        setStreak(newStreak);
        if (newStreak > bestStreak) setBestStreak(newStreak);
      } else {
        sound.playError();
        setStreak(0);
      }

      setHistory((prev) => [...prev, { question: currentQ, selected: index, result: res }]);
    } catch (err) {
      // Local fallback in case network hiccup
      const isCorrect = currentQ.correctIndex === index;
      const points = isCorrect ? 100 : 0;
      const res: ValidationResponse = {
        success: true,
        questionId: currentQ.id,
        isCorrect,
        correctIndex: currentQ.correctIndex ?? 0,
        explanation: currentQ.explanation || 'Answer recorded.',
        concept: currentQ.concept || 'Business Core',
        examTip: currentQ.examTip || 'Key MBA concept.',
        points,
      };
      setValidationResult(res);
      if (isCorrect) {
        sound.playSuccess();
        setScore((prev) => prev + points);
        setCorrectAnswersCount((prev) => prev + 1);
      } else {
        sound.playError();
      }
    } finally {
      setIsValidating(false);
    }
  };

  // Advance to next question or complete
  const handleNext = () => {
    sound.playClick();
    if (currentIndex + 1 < questions.length) {
      setCurrentIndex((prev) => prev + 1);
      setSelectedOption(null);
      setValidationResult(null);
      setTimeLeft(30);
    } else {
      finishQuiz();
    }
  };

  // End of quiz handling
  const finishQuiz = () => {
    setGameState('review');
    const accuracy = questions.length ? Math.round((correctAnswersCount / questions.length) * 100) : 0;
    
    // Award XP
    const earnedXp = Math.round(score + correctAnswersCount * 50);
    let badgeToAward = undefined;
    if (accuracy >= 80) badgeToAward = 'quiz_ace';

    addXpAndProgress(earnedXp, badgeToAward);
    if (onRefreshProfile) onRefreshProfile();

    if (accuracy >= 60) {
      sound.playLevelUp();
      confetti({
        particleCount: 100,
        spread: 70,
        origin: { y: 0.6 },
      });
    }
  };

  // Submit to Global Leaderboard
  const handleSubmitToLeaderboard = async () => {
    const profile = getProfile();
    setIsSubmitting(true);
    sound.playClick();

    const accuracy = questions.length ? Math.round((correctAnswersCount / questions.length) * 100) : 0;
    const res = await submitScore({
      playerName: profile.name,
      college: profile.college,
      specialization: profile.specialization,
      score: score,
      xp: profile.xp,
      level: profile.level,
      accuracy,
      streak: Math.max(profile.streak, bestStreak),
      badges: profile.badges,
    });

    setIsSubmitting(false);
    if (res.success) {
      sound.playSuccess();
      setSubmissionSuccess(`Score successfully posted! Your Global Rank: #${res.rank || 1}`);
    } else {
      alert('Failed to submit score. Please try again.');
    }
  };

  const currentQ = questions[currentIndex];
  const timerPercent = (timeLeft / 30) * 100;

  return (
    <div className="max-w-4xl mx-auto py-6 px-4">
      {/* LOBBY / SETUP SCREEN */}
      {gameState === 'lobby' && (
        <div className="glass-panel rounded-2xl p-6 sm:p-8 border border-slate-800 shadow-2xl space-y-8">
          <div className="text-center space-y-3">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-indigo-500/10 border border-indigo-500/20 text-indigo-400 text-xs font-semibold">
              <Sparkles className="w-3.5 h-3.5" />
              <span>Competitive MBA Test Arena</span>
            </div>
            <h1 className="text-3xl sm:text-4xl font-extrabold text-white font-heading">
              MBA Quiz <span className="gradient-text">Challenge</span>
            </h1>
            <p className="text-slate-400 max-w-xl mx-auto text-sm sm:text-base">
              Test your grasp on core MBA curricula: Porter's strategies, financial equations, Herzberg theories, and unit economics with real-time server validation.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 bg-slate-900/60 p-6 rounded-xl border border-slate-800">
            {/* Category Filter */}
            <div className="space-y-2">
              <label className="text-xs font-bold text-slate-300 uppercase tracking-wider">Subject Category</label>
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value)}
                className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-sm text-white focus:outline-none focus:border-indigo-500"
              >
                {categories.map((c) => (
                  <option key={c} value={c}>
                    {c === 'All' ? '🎯 All Categories (Mixed)' : c}
                  </option>
                ))}
              </select>
            </div>

            {/* Difficulty Filter */}
            <div className="space-y-2">
              <label className="text-xs font-bold text-slate-300 uppercase tracking-wider">Difficulty Level</label>
              <select
                value={difficulty}
                onChange={(e) => setDifficulty(e.target.value)}
                className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-sm text-white focus:outline-none focus:border-indigo-500"
              >
                {difficulties.map((d) => (
                  <option key={d} value={d}>
                    {d === 'All' ? '⚡ Any Difficulty' : d}
                  </option>
                ))}
              </select>
            </div>

            {/* Question Count */}
            <div className="space-y-2">
              <label className="text-xs font-bold text-slate-300 uppercase tracking-wider">Question Count</label>
              <div className="grid grid-cols-3 gap-2">
                {[5, 10, 15].map((cnt) => (
                  <button
                    key={cnt}
                    onClick={() => setQuestionCount(cnt)}
                    className={`py-2 text-xs font-bold rounded-lg border transition ${
                      questionCount === cnt
                        ? 'bg-indigo-600 text-white border-indigo-400'
                        : 'bg-slate-800 text-slate-300 border-slate-700 hover:bg-slate-700'
                    }`}
                  >
                    {cnt} Qs
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Feature Highlights */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-2">
            <div className="flex items-center gap-3 p-3.5 rounded-xl bg-slate-900/40 border border-slate-800/80">
              <Timer className="w-5 h-5 text-amber-400 shrink-0" />
              <div>
                <p className="text-xs font-bold text-white">30s Per Question</p>
                <p className="text-[11px] text-slate-400">Builds CAT/GMAT time speed</p>
              </div>
            </div>
            <div className="flex items-center gap-3 p-3.5 rounded-xl bg-slate-900/40 border border-slate-800/80">
              <Brain className="w-5 h-5 text-indigo-400 shrink-0" />
              <div>
                <p className="text-xs font-bold text-white">Exam Tips & Concepts</p>
                <p className="text-[11px] text-slate-400">In-depth explanations per answer</p>
              </div>
            </div>
            <div className="flex items-center gap-3 p-3.5 rounded-xl bg-slate-900/40 border border-slate-800/80">
              <Award className="w-5 h-5 text-emerald-400 shrink-0" />
              <div>
                <p className="text-xs font-bold text-white">Streak Multipliers</p>
                <p className="text-[11px] text-slate-400">1.5x score bonus for consecutive hits</p>
              </div>
            </div>
          </div>

          {/* Action Button */}
          <div className="pt-4 flex flex-col sm:flex-row gap-3">
            <button
              onClick={handleStartQuiz}
              className="flex-1 py-4 px-6 rounded-xl bg-gradient-to-r from-blue-600 via-indigo-600 to-purple-600 hover:from-blue-500 hover:to-purple-500 text-white font-bold text-base shadow-lg shadow-indigo-500/25 transition transform hover:-translate-y-0.5 cursor-pointer flex items-center justify-center gap-2"
            >
              <Sparkles className="w-5 h-5" />
              <span>Launch Quiz Session</span>
            </button>
            {onBackToGames && (
              <button
                onClick={onBackToGames}
                className="py-4 px-6 rounded-xl bg-slate-800 text-slate-300 hover:text-white hover:bg-slate-700 text-sm font-semibold transition"
              >
                Back to Games
              </button>
            )}
          </div>
        </div>
      )}

      {/* PLAYING SCREEN */}
      {gameState === 'playing' && currentQ && (
        <div className="space-y-6">
          {/* Top Bar: Progress, Timer, Live Score */}
          <div className="glass-panel rounded-2xl p-4 sm:p-5 border border-slate-800 flex flex-wrap items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <span className="text-xs font-bold px-2.5 py-1 rounded-md bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">
                Q {currentIndex + 1} of {questions.length}
              </span>
              <span className="text-xs font-semibold text-slate-400 hidden sm:inline">
                {currentQ.category} • <span className="text-slate-300">{currentQ.difficulty}</span>
              </span>
            </div>

            {/* Streak & Score Counters */}
            <div className="flex items-center gap-4">
              {streak > 1 && (
                <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-md bg-amber-500/20 text-amber-300 border border-amber-500/40 text-xs font-bold animate-bounce">
                  <Flame className="w-3.5 h-3.5 text-amber-400" />
                  <span>{streak}x Combo!</span>
                </div>
              )}
              <div className="text-right">
                <span className="text-xs text-slate-400">Score</span>
                <p className="text-lg font-extrabold text-white leading-none font-heading">{score}</p>
              </div>
            </div>
          </div>

          {/* Timer Bar */}
          <div className="w-full bg-slate-800/80 rounded-full h-2.5 overflow-hidden border border-slate-700">
            <div
              className={`h-full transition-all duration-1000 ${
                timeLeft > 10 ? 'bg-indigo-500' : 'bg-rose-500 animate-pulse'
              }`}
              style={{ width: `${timerPercent}%` }}
            />
          </div>

          {/* Question Card */}
          <div className="glass-panel rounded-2xl p-6 sm:p-8 border border-slate-800 space-y-6 shadow-xl">
            <div className="flex items-start justify-between gap-4">
              <h2 className="text-lg sm:text-xl font-bold text-white leading-relaxed">
                {currentQ.question}
              </h2>
              <div className="shrink-0 flex items-center gap-1 text-slate-400 text-xs bg-slate-900/80 px-2.5 py-1.5 rounded-lg border border-slate-700">
                <Timer className={`w-3.5 h-3.5 ${timeLeft <= 5 ? 'text-rose-400 animate-ping' : 'text-slate-400'}`} />
                <span className={`font-bold ${timeLeft <= 5 ? 'text-rose-400' : 'text-white'}`}>{timeLeft}s</span>
              </div>
            </div>

            {/* 4 Options Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
              {currentQ.options.map((opt, idx) => {
                const isSelected = selectedOption === idx;
                let optionClasses = 'bg-slate-900/70 border-slate-800 text-slate-200 hover:border-indigo-500/50 hover:bg-slate-800/80';

                if (validationResult !== null) {
                  if (idx === validationResult.correctIndex) {
                    optionClasses = 'bg-emerald-950/70 border-emerald-500 text-emerald-200 font-semibold shadow-lg shadow-emerald-950/50';
                  } else if (isSelected && !validationResult.isCorrect) {
                    optionClasses = 'bg-rose-950/70 border-rose-500 text-rose-200 font-semibold shadow-lg shadow-rose-950/50';
                  } else {
                    optionClasses = 'bg-slate-900/40 border-slate-800/60 text-slate-500 opacity-60';
                  }
                } else if (isSelected) {
                  optionClasses = 'bg-indigo-900/40 border-indigo-400 text-white';
                }

                return (
                  <button
                    key={idx}
                    disabled={validationResult !== null || isValidating}
                    onClick={() => handleSelectOption(idx)}
                    className={`relative p-4 rounded-xl border text-left text-sm transition-all flex items-start gap-3 cursor-pointer ${optionClasses}`}
                  >
                    <span className="w-6 h-6 rounded-lg bg-slate-800/90 border border-slate-700 flex items-center justify-center text-xs font-bold shrink-0 text-slate-300">
                      {String.fromCharCode(65 + idx)}
                    </span>
                    <span className="flex-1 pt-0.5 leading-snug">{opt}</span>

                    {/* Feedback Icons */}
                    {validationResult !== null && idx === validationResult.correctIndex && (
                      <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0 mt-0.5" />
                    )}
                    {validationResult !== null && isSelected && !validationResult.isCorrect && (
                      <XCircle className="w-5 h-5 text-rose-400 shrink-0 mt-0.5" />
                    )}
                  </button>
                );
              })}
            </div>

            {/* Server-Verified Detailed Feedback Banner */}
            {validationResult && (
              <div
                className={`p-5 rounded-xl border space-y-3 animate-in fade-in slide-in-from-top-2 duration-300 ${
                  validationResult.isCorrect
                    ? 'bg-emerald-950/30 border-emerald-500/40 text-emerald-100'
                    : 'bg-rose-950/30 border-rose-500/40 text-rose-100'
                }`}
              >
                <div className="flex items-center gap-2">
                  {validationResult.isCorrect ? (
                    <CheckCircle2 className="w-5 h-5 text-emerald-400" />
                  ) : (
                    <XCircle className="w-5 h-5 text-rose-400" />
                  )}
                  <span className="font-bold text-sm">
                    {validationResult.isCorrect ? 'Correct Answer!' : 'Incorrect Choice'}
                  </span>
                  {validationResult.isCorrect && (
                    <span className="ml-auto text-xs font-bold text-emerald-300 bg-emerald-900/50 px-2 py-0.5 rounded border border-emerald-700/40">
                      +{validationResult.points} Points
                    </span>
                  )}
                </div>

                <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
                  {validationResult.explanation}
                </p>

                {/* Educational Concept & CAT/GMAT Exam Tip */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2 text-xs">
                  {validationResult.concept && (
                    <div className="bg-slate-900/70 p-3 rounded-lg border border-slate-800 flex items-start gap-2">
                      <Brain className="w-4 h-4 text-indigo-400 shrink-0 mt-0.5" />
                      <div>
                        <strong className="text-indigo-300 block font-semibold">Core Concept:</strong>
                        <span className="text-slate-300">{validationResult.concept}</span>
                      </div>
                    </div>
                  )}
                  {validationResult.examTip && (
                    <div className="bg-slate-900/70 p-3 rounded-lg border border-slate-800 flex items-start gap-2">
                      <Lightbulb className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                      <div>
                        <strong className="text-amber-300 block font-semibold">Entrance Exam Tip:</strong>
                        <span className="text-slate-300">{validationResult.examTip}</span>
                      </div>
                    </div>
                  )}
                </div>

                <div className="pt-2 flex justify-end">
                  <button
                    onClick={handleNext}
                    className="py-2.5 px-6 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-sm flex items-center gap-2 shadow-lg transition cursor-pointer"
                  >
                    <span>{currentIndex + 1 === questions.length ? 'Finish Session' : 'Next Question'}</span>
                    <ArrowRight className="w-4 h-4" />
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* REVIEW & SCOREBOARD SCREEN */}
      {gameState === 'review' && (
        <div className="space-y-6">
          <div className="glass-panel rounded-2xl p-6 sm:p-8 border border-slate-800 text-center space-y-6">
            <div className="w-16 h-16 rounded-2xl bg-gradient-to-tr from-amber-500 to-indigo-600 mx-auto flex items-center justify-center text-white shadow-xl shadow-indigo-500/20">
              <Award className="w-8 h-8" />
            </div>

            <div>
              <h2 className="text-2xl sm:text-3xl font-extrabold text-white font-heading">
                Quiz Session <span className="gradient-text">Complete!</span>
              </h2>
              <p className="text-slate-400 text-sm mt-1">Here is how you performed against standard MBA assessment metrics.</p>
            </div>

            {/* Score Cards */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              <div className="bg-slate-900/80 p-4 rounded-xl border border-slate-800">
                <span className="text-xs text-slate-400">Total Score</span>
                <p className="text-2xl font-black text-indigo-400 font-heading">{score}</p>
              </div>
              <div className="bg-slate-900/80 p-4 rounded-xl border border-slate-800">
                <span className="text-xs text-slate-400">Accuracy</span>
                <p className="text-2xl font-black text-emerald-400 font-heading">
                  {questions.length ? Math.round((correctAnswersCount / questions.length) * 100) : 0}%
                </p>
              </div>
              <div className="bg-slate-900/80 p-4 rounded-xl border border-slate-800">
                <span className="text-xs text-slate-400">Correct Answers</span>
                <p className="text-2xl font-black text-white font-heading">
                  {correctAnswersCount} / {questions.length}
                </p>
              </div>
              <div className="bg-slate-900/80 p-4 rounded-xl border border-slate-800">
                <span className="text-xs text-slate-400">Best Streak</span>
                <p className="text-2xl font-black text-amber-400 font-heading">{bestStreak} 🔥</p>
              </div>
            </div>

            {/* Submit to Global Leaderboard */}
            <div className="bg-indigo-950/40 p-5 rounded-xl border border-indigo-500/30 text-left space-y-3">
              <div className="flex items-center justify-between">
                <div>
                  <h4 className="text-sm font-bold text-white flex items-center gap-2">
                    <Award className="w-4 h-4 text-amber-400" />
                    Submit to Global MBA Leaderboard
                  </h4>
                  <p className="text-xs text-indigo-300">
                    Post your score of <strong>{score} pts</strong> under your registered profile.
                  </p>
                </div>
                <button
                  disabled={isSubmitting || submissionSuccess !== null}
                  onClick={handleSubmitToLeaderboard}
                  className={`py-2 px-4 rounded-lg font-bold text-xs flex items-center gap-1.5 transition ${
                    submissionSuccess
                      ? 'bg-emerald-600 text-white cursor-default'
                      : 'bg-indigo-600 hover:bg-indigo-500 text-white cursor-pointer'
                  }`}
                >
                  {submissionSuccess ? (
                    <>
                      <Check className="w-3.5 h-3.5" />
                      <span>Posted!</span>
                    </>
                  ) : isSubmitting ? (
                    <span>Posting...</span>
                  ) : (
                    <>
                      <Send className="w-3.5 h-3.5" />
                      <span>Submit Score</span>
                    </>
                  )}
                </button>
              </div>
              {submissionSuccess && (
                <p className="text-xs text-emerald-300 font-medium">{submissionSuccess}</p>
              )}
            </div>

            {/* Action Buttons */}
            <div className="flex flex-wrap items-center justify-center gap-3 pt-2">
              <button
                onClick={handleStartQuiz}
                className="py-3 px-6 rounded-xl bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white font-bold text-sm shadow-md transition flex items-center gap-2 cursor-pointer"
              >
                <RotateCcw className="w-4 h-4" />
                <span>Play Again</span>
              </button>
              <button
                onClick={() => setGameState('lobby')}
                className="py-3 px-6 rounded-xl bg-slate-800 text-slate-300 hover:text-white hover:bg-slate-700 text-sm font-semibold transition"
              >
                Change Category & Settings
              </button>
              {onBackToGames && (
                <button
                  onClick={onBackToGames}
                  className="py-3 px-6 rounded-xl bg-slate-900 border border-slate-700 text-slate-300 hover:text-white text-sm font-semibold transition"
                >
                  Back to Games Hub
                </button>
              )}
            </div>
          </div>

          {/* Detailed Question Review List */}
          <div className="space-y-4">
            <h3 className="text-lg font-bold text-white font-heading">Session Review & Concepts</h3>
            {history.map((item, idx) => (
              <div
                key={idx}
                className={`p-5 rounded-xl border space-y-2.5 ${
                  item.result.isCorrect
                    ? 'bg-slate-900/60 border-emerald-900/40'
                    : 'bg-slate-900/60 border-rose-900/40'
                }`}
              >
                <div className="flex items-start gap-2.5 justify-between">
                  <div className="flex items-start gap-2">
                    <span className="text-xs font-bold px-2 py-0.5 rounded bg-slate-800 text-slate-300">
                      Q{idx + 1}
                    </span>
                    <p className="text-sm font-semibold text-white">{item.question.question}</p>
                  </div>
                  {item.result.isCorrect ? (
                    <span className="text-xs font-bold text-emerald-400 bg-emerald-950/60 px-2 py-0.5 rounded border border-emerald-800/40 shrink-0">
                      Correct
                    </span>
                  ) : (
                    <span className="text-xs font-bold text-rose-400 bg-rose-950/60 px-2 py-0.5 rounded border border-rose-800/40 shrink-0">
                      Missed
                    </span>
                  )}
                </div>

                <div className="text-xs text-slate-300 space-y-1 pl-7">
                  <p>
                    <span className="text-slate-400">Correct Answer:</span>{' '}
                    <strong className="text-emerald-300">
                      {item.question.options[item.result.correctIndex]}
                    </strong>
                  </p>
                  {item.selected !== -1 && !item.result.isCorrect && (
                    <p>
                      <span className="text-slate-400">Your Choice:</span>{' '}
                      <span className="text-rose-300 line-through">
                        {item.question.options[item.selected]}
                      </span>
                    </p>
                  )}
                  <p className="text-slate-400 pt-1 leading-relaxed">{item.result.explanation}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
