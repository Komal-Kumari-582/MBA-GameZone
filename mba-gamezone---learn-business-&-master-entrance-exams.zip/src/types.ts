export type Category = 
  | 'All'
  | 'Marketing'
  | 'Finance'
  | 'HR'
  | 'Economics'
  | 'Business Strategy'
  | 'Entrepreneurship';

export type Difficulty = 'All' | 'Beginner' | 'Intermediate' | 'Advanced';

export interface Question {
  id: string;
  category: string;
  difficulty: string;
  question: string;
  options: string[];
  correctIndex?: number;
  explanation?: string;
  concept?: string;
  examTip?: string;
}

export interface ValidationResponse {
  success: boolean;
  questionId: string;
  isCorrect: boolean;
  correctIndex: number;
  explanation: string;
  concept: string;
  examTip: string;
  points: number;
}

export interface LeaderboardEntry {
  id: string;
  playerName: string;
  college: string;
  specialization: string;
  score: number;
  xp: number;
  level: string;
  accuracy: number;
  streak: number;
  badges: string[];
  date: string;
}

export interface UserProfile {
  name: string;
  college: string;
  specialization: string;
  xp: number;
  level: string;
  streak: number;
  lastPlayedDate: string;
  badges: string[];
  gamesPlayed: number;
  quizzesTaken: number;
  soundEnabled: boolean;
}

export interface GameMetadata {
  id: string;
  title: string;
  category: string;
  tagline: string;
  description: string;
  icon: string;
  difficulty: 'Beginner' | 'Intermediate' | 'Advanced';
  duration: string;
  xpReward: number;
  color: string;
}
