import { LeaderboardEntry, Question, ValidationResponse } from '../types';

export const API_BASE = '/api';

export async function fetchQuestions(category = 'All', difficulty = 'All', limit?: number): Promise<Question[]> {
  try {
    const params = new URLSearchParams();
    if (category !== 'All') params.append('category', category);
    if (difficulty !== 'All') params.append('difficulty', difficulty);
    if (limit) params.append('limit', String(limit));

    const res = await fetch(`${API_BASE}/questions?${params.toString()}`);
    if (!res.ok) throw new Error(`HTTP error: ${res.status}`);
    const data = await res.json();
    return data.questions || [];
  } catch (err) {
    console.error('Failed to fetch questions from API:', err);
    return [];
  }
}

export async function validateQuizAnswer(questionId: string, selectedIndex: number): Promise<ValidationResponse> {
  try {
    const res = await fetch(`${API_BASE}/quiz/validate`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ questionId, selectedIndex }),
    });
    if (!res.ok) throw new Error(`HTTP error: ${res.status}`);
    return await res.json();
  } catch (err) {
    console.error('Failed to validate quiz answer on server:', err);
    throw err;
  }
}

export async function fetchLeaderboard(): Promise<LeaderboardEntry[]> {
  try {
    const res = await fetch(`${API_BASE}/leaderboard`);
    if (!res.ok) throw new Error(`HTTP error: ${res.status}`);
    const data = await res.json();
    return data.leaderboard || [];
  } catch (err) {
    console.error('Failed to fetch leaderboard:', err);
    return [];
  }
}

export async function submitScore(entry: {
  playerName: string;
  college: string;
  specialization: string;
  score: number;
  xp: number;
  level: string;
  accuracy: number;
  streak: number;
  badges: string[];
}): Promise<{ success: boolean; rank?: number; totalPlayers?: number }> {
  try {
    const res = await fetch(`${API_BASE}/leaderboard`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(entry),
    });
    if (!res.ok) throw new Error(`HTTP error: ${res.status}`);
    return await res.json();
  } catch (err) {
    console.error('Failed to submit score:', err);
    return { success: false };
  }
}

export async function fetchScenario(gameId: string): Promise<any> {
  try {
    const res = await fetch(`${API_BASE}/scenarios/${gameId}`);
    if (!res.ok) throw new Error(`HTTP error: ${res.status}`);
    const data = await res.json();
    return data.data;
  } catch (err) {
    console.error(`Failed to fetch scenario for ${gameId}:`, err);
    return null;
  }
}

export async function fetchPlatformStats(): Promise<any> {
  try {
    const res = await fetch(`${API_BASE}/stats`);
    if (!res.ok) throw new Error(`HTTP error: ${res.status}`);
    const data = await res.json();
    return data.stats;
  } catch (err) {
    console.error('Failed to fetch platform stats:', err);
    return {
      totalGames: 7,
      totalQuestions: 15,
      totalPlayers: 8,
      avgScore: 2370,
      categoriesCount: 6,
      activeSimulations: 6,
    };
  }
}

export async function fetchDailyChallenge(): Promise<any> {
  try {
    const res = await fetch(`${API_BASE}/daily-challenge`);
    if (!res.ok) throw new Error(`HTTP error: ${res.status}`);
    const data = await res.json();
    return data.challenge;
  } catch (err) {
    console.error('Failed to fetch daily challenge:', err);
    return null;
  }
}
