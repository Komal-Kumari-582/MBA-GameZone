import { UserProfile } from '../types';

const STORAGE_KEY = 'mba_gamezone_profile';

export const LEVELS = [
  { level: 'Intern Aspirant', minXp: 0, maxXp: 300, icon: '🌱' },
  { level: 'Management Trainee', minXp: 300, maxXp: 800, icon: '📋' },
  { level: 'Associate Consultant', minXp: 800, maxXp: 1600, icon: '📊' },
  { level: 'Product & Brand Lead', minXp: 1600, maxXp: 2800, icon: '🚀' },
  { level: 'Director of Strategy', minXp: 2800, maxXp: 4500, icon: '💼' },
  { level: 'Vice President (VP)', minXp: 4500, maxXp: 7000, icon: '🏛️' },
  { level: 'Chief Executive (CXO)', minXp: 7000, maxXp: Infinity, icon: '👑' },
];

export const ALL_BADGES = [
  { id: 'first_game', name: 'First Step', description: 'Complete your first educational game', icon: '🎯' },
  { id: 'quiz_ace', name: 'Quiz Master', description: 'Score 80%+ on any timed MBA Quiz', icon: '🧠' },
  { id: 'strategy_pro', name: 'Strategy Titan', description: 'Successfully finish the Business Strategy simulation', icon: '♟️' },
  { id: 'marketing_pro', name: 'Marketing Maverick', description: 'Design a winning 4Ps GTM launch campaign', icon: '📣' },
  { id: 'finance_whiz', name: 'Wall Street Wizard', description: 'Solve balance sheet and valuation challenges', icon: '📈' },
  { id: 'hr_champion', name: 'Culture Architect', description: 'Balance executive HR dilemmas and team morale', icon: '🤝' },
  { id: 'unicorn_founder', name: 'Unicorn Founder', description: 'Close Series A in the Entrepreneurship Simulator', icon: '🦄' },
  { id: 'case_champion', name: 'Case Champion', description: 'Solve the executive Harvard/Stanford case study', icon: '🏆' },
  { id: 'streak_3', name: 'Consistent Thinker', description: 'Maintain a 3-day learning streak', icon: '🔥' },
];

export function getProfile(): UserProfile {
  try {
    const data = localStorage.getItem(STORAGE_KEY);
    if (data) {
      return JSON.parse(data);
    }
  } catch (e) {
    console.error('Failed to read from localStorage', e);
  }

  // Default profile
  const initial: UserProfile = {
    name: 'MBA Aspirant',
    college: 'Business School Candidate',
    specialization: 'General Management',
    xp: 150,
    level: 'Intern Aspirant',
    streak: 1,
    lastPlayedDate: new Date().toISOString().split('T')[0],
    badges: ['First Step'],
    gamesPlayed: 0,
    quizzesTaken: 0,
    soundEnabled: true,
  };

  saveProfile(initial);
  return initial;
}

export function saveProfile(profile: UserProfile): void {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(profile));
  } catch (e) {
    console.error('Failed to save to localStorage', e);
  }
}

export function calculateLevel(xp: number): { level: string; icon: string; minXp: number; maxXp: number; progressPercent: number } {
  const current = LEVELS.find((l) => xp >= l.minXp && xp < l.maxXp) || LEVELS[LEVELS.length - 1];
  const nextMax = current.maxXp === Infinity ? current.minXp + 5000 : current.maxXp;
  const range = nextMax - current.minXp;
  const progress = Math.min(100, Math.max(0, Math.round(((xp - current.minXp) / range) * 100)));

  return {
    level: current.level,
    icon: current.icon,
    minXp: current.minXp,
    maxXp: nextMax,
    progressPercent: progress,
  };
}

export function addXpAndProgress(xpGained: number, badgeIdToAward?: string): { profile: UserProfile; leveledUp: boolean; newBadgeAwarded: string | null } {
  const profile = getProfile();
  const oldLevelInfo = calculateLevel(profile.xp);
  
  profile.xp += xpGained;
  profile.gamesPlayed += 1;

  // Streak update
  const today = new Date().toISOString().split('T')[0];
  if (profile.lastPlayedDate !== today) {
    const yesterday = new Date(Date.now() - 86400000).toISOString().split('T')[0];
    if (profile.lastPlayedDate === yesterday) {
      profile.streak += 1;
    } else {
      profile.streak = 1;
    }
    profile.lastPlayedDate = today;
  }

  const newLevelInfo = calculateLevel(profile.xp);
  profile.level = newLevelInfo.level;
  const leveledUp = newLevelInfo.level !== oldLevelInfo.level;

  let newBadgeAwarded: string | null = null;
  if (badgeIdToAward) {
    const badgeObj = ALL_BADGES.find((b) => b.id === badgeIdToAward);
    if (badgeObj && !profile.badges.includes(badgeObj.name)) {
      profile.badges.push(badgeObj.name);
      newBadgeAwarded = badgeObj.name;
    }
  }

  // Auto streak badge
  if (profile.streak >= 3 && !profile.badges.includes('Consistent Thinker')) {
    profile.badges.push('Consistent Thinker');
    newBadgeAwarded = newBadgeAwarded || 'Consistent Thinker';
  }

  saveProfile(profile);
  return { profile, leveledUp, newBadgeAwarded };
}
